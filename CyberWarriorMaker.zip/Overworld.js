class Overworld {
 constructor(config) {
   this.element = config.element;
   this.canvas = this.element.querySelector(".game-canvas");
   this.ctx = this.canvas.getContext("2d");
   this.map = null;
 }

  startGameLoop() {
    const step = () => {
      //Clear off the canvas
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

      //Establish the camera person
      const cameraPerson = this.map.gameObjects.hero;

      //Update all objects
      Object.values(this.map.gameObjects).forEach(object => {
        object.update({
          arrow: this.directionInput.direction,
          map: this.map,
        })
      })
      

      //Draw Lower layer
      this.map.drawLowerImage(this.ctx, cameraPerson);

      //Draw Game Objects

	  
	  this.apple = []
	  this.orange = []
      this.kiwi = []
	  this.quest = []

	  Object.values(this.map.gameObjects).forEach(object => {

		  if (object.who == "object"){this.apple.push(object);}
          else if (object.who == "animation_object"){this.kiwi.push(object);}
		  else if (object.who == "quest"){this.quest.push(object);}
		  else { this.orange.push(object); }

	  });
      //Draw Upper layer

      Object.values(this.orange).sort((a,b) => {	
        return a.y - b.y;
      }).forEach(object => {
        object.sprite.draw(this.ctx, cameraPerson);
      })
      Object.values(this.kiwi).sort((a,b) => {	
        return a.y - b.y;
      }).forEach(object => {
        object.sprite.draw(this.ctx, cameraPerson);
      })	
      Object.values(this.apple).sort((a,b) => {
        return a.y - b.y;
      }).forEach(object => {
        object.sprite.draw(this.ctx, cameraPerson);
      })
      Object.values(this.quest).sort((a,b) => {
        return a.y - b.y;
      }).forEach(object => {
        object.sprite.draw(this.ctx, cameraPerson);
      })	  
	  //console.log(cameraPerson);
	  
      this.map.drawUpperImage(this.ctx, cameraPerson);
      
      if (!this.map.isPaused) {
        requestAnimationFrame(() => {
          step();   
        })
      }
    }
    step();
 }

 bindActionInput() {
   new KeyPressListener("Enter", () => {
     //Is there a person here to talk to?
     this.map.checkForActionCutscene()
   })
 }

 bindHeroPositionCheck() {
   document.addEventListener("PersonWalkingComplete", e => {
     if (e.detail.whoId === "hero") {
       //Hero's position has changed
       this.map.checkForFootstepCutscene()
     }
   })
 }

 startMap(mapConfig, heroInitialState=null) {
  this.map = new OverworldMap(mapConfig);
  this.map.overworld = this;
  this.map.mountObjects();

  if (heroInitialState) {
    const {hero} = this.map.gameObjects;
    this.map.removeWall(hero.x, hero.y);
    hero.x = heroInitialState.x;
    hero.y = heroInitialState.y;
    hero.direction = heroInitialState.direction;
	
    this.map.addWall(hero.x, hero.y);
  }

  this.progress.mapId = mapConfig.id;
  this.progress.startingHeroX = this.map.gameObjects.hero.x;
  this.progress.startingHeroY = this.map.gameObjects.hero.y;
  this.progress.startingHeroDirection = this.map.gameObjects.hero.direction;

 }

 async init() {

  const container = document.querySelector(".game-container");

  this.progress = new Progress();

  this.titleScreen = new TitleScreen({
    progress: this.progress
  })
  const useSaveFile = await this.titleScreen.init(container);

  let initialHeroState = null;
  let isNewGame = false;
  
  if (useSaveFile) {
	this.progress.load();
	initialHeroState = {
		x: this.progress.startingHeroX,
		y: this.progress.startingHeroY,
		direction: this.progress.startingHeroDirection,
	}
	isNewGame=true;
  }

  this.startMap(window.OverworldMaps[this.progress.mapId], initialHeroState );

  this.bindActionInput();
  this.bindHeroPositionCheck();

  this.directionInput = new DirectionInput();
  this.directionInput.init();

  this.startGameLoop();
  
  if(!isNewGame){//비동기 처리 promise로 해결하려했으나 GG. 시간나면 고민해볼 것
	this.map.startCutscene(
		[
			{ type: "textMessage", text: "ENTER을 치면 대화를 넘길 수 있습니다."},
			{ type: "inputTextMessage", text: "관등성명 입력(ex.권순우 상병)"},
			{ type: "textMessage", text: "키보드의 화살표 ← → ↑ ↓ 를 누르면 캐릭터가 움직입니다."},
			{ type: "textMessage", text: "NPC(인물)앞에서 ENTER을 누르면 대화를 시작할 수 있습니다."},
			{ type: "textMessage", text: "상황에 적절하게 대처하지 못하면 좌측 상단의 하트가 하나씩 사라지니 주의하세요!"},
			{ type: "textMessage", text: "각각의 상황을 헤쳐나가면 칭호를 얻을 수 있으며, ^칭호를 획득하면 하트 아래에 표시됩니다."},
            { type: "textMessage", text: "그럼 새로운 부대에서의 당신의 새로운 군생활을 응원하겠습니다! 화이팅!"},
            { type: "textMessage", text: "(위에 보이는 부대로 들어가보자)"},
			{ type: "addStoryFlag", flag: "시작"},
			{ type: "addStoryFlag", flag: "출입완료"},
		])
  }
 }
}
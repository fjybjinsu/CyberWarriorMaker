class OverworldEvent {
  constructor({ map, event}) {
    this.map = map;
    this.event = event;
  }

  stand(resolve) {
    const who = this.map.gameObjects[ this.event.who ];
    who.startBehavior({
      map: this.map
    }, {
      type: "stand",
      direction: this.event.direction,
      time: this.event.time
    })
    
    //Set up a handler to complete when correct person is done walking, then resolve the event
    const completeHandler = e => {
      if (e.detail.whoId === this.event.who) {
        document.removeEventListener("PersonStandComplete", completeHandler);
        resolve();
      }
    }
    document.addEventListener("PersonStandComplete", completeHandler)
  }

  walk(resolve) {
    const who = this.map.gameObjects[ this.event.who ];
    who.startBehavior({
      map: this.map
    }, {
      type: "walk",
      direction: this.event.direction,
      retry: true
    })

    //Set up a handler to complete when correct person is done walking, then resolve the event
    const completeHandler = e => {
      if (e.detail.whoId === this.event.who) {
        document.removeEventListener("PersonWalkingComplete", completeHandler);
        resolve();
      }
    }
    document.addEventListener("PersonWalkingComplete", completeHandler);
  }
  
  inputTextMessage(resolve) {

    if (this.event.faceHero) {
      const obj = this.map.gameObjects[this.event.faceHero];
      obj.direction = utils.oppositeDirection(this.map.gameObjects["hero"].direction);
    }

    const message = new inputTextMessage({
      text: this.event.text,
      onComplete: () => resolve()
    })
    message.init( document.querySelector(".game-container") )
	document.querySelector(".in").focus();
  }

  textMessage(resolve) {
	if(this.event.book){book_force = this.event.book;}
    if (this.event.faceHero) {
      const obj = this.map.gameObjects[this.event.faceHero];
      obj.direction = utils.oppositeDirection(this.map.gameObjects["hero"].direction);
    }
    const message = new TextMessage({
      text: this.event.text.replaceAll('$name',window.playerState.storyFlags['캐릭터이름']),
      onComplete: () => resolve()
    })
	
    message.init( document.querySelector(".game-container") )
  }
  
  QuizMessage(resolve) {
    if (this.event.faceHero) {
      const obj = this.map.gameObjects[this.event.faceHero];
      obj.direction = utils.oppositeDirection(this.map.gameObjects["hero"].direction);
    }

    const Quiz = new QuizMessage({
      text: this.event.text,
      onComplete: (isSolved) => {
		  resolve(isSolved ? "SOLVE_QUIZ" : "UNSOLVE_QUIZ");
	  }
    });
    Quiz.option=this.event.option;
    Quiz.ans=this.event.ans;
    Quiz.init( document.querySelector(".game-container") )
  }

  EndingCredit(resolve){
	const endingPage=document.createElement("img");
	endingPage.setAttribute("src","./images/ending.png");
	endingPage.setAttribute("class","endingPage");
	
	const container=document.querySelector(".game-container");
	
	const sceneTransition= new SceneTransition();
	sceneTransition.init(document.body, () =>{
		document.querySelector(".game-container").remove();
		document.querySelector(".book_big").remove();
		sceneTransition.fadeOut();
		document.body.append(endingPage);
		resolve();
	})
  }

  changeMap(resolve) {
    const sceneTransition = new SceneTransition();
    sceneTransition.init(document.querySelector(".game-container"), () => {
      this.map.overworld.startMap( window.OverworldMaps[this.event.map], {
        x: this.event.x,
        y: this.event.y,
        direction: this.event.direction,
      });
      resolve();
      sceneTransition.fadeOut();
	  this.map.overworld.progress.save();
    })
  }

  addStoryFlag(resolve) {
	if(this.event.flag==='사이버보안가이드')  document.querySelector('.book_big').style.display='';
    window.playerState.storyFlags[this.event.flag] = true;
	checkTitle(this.map);
    resolve();
  }
  // 건우가 추가함 delStoryFlag 
  
  delStoryFlag(resolve) {
    window.playerState.storyFlags[this.event.flag] = false;
    resolve();
  }
  init() {
    return new Promise(resolve => {
      this[this.event.type](resolve)      
    })
  }
}
let title="　갓 전입 온 간부　";
function checkTitle(overWorldMap){
	storyFlags=window.playerState.storyFlags;
	const titleAFlags=["중대장1","행정보급관1","분대장1","박격포반장1",]; //변수안에 칭호를 얻기 위한, storyFlag값들 정리
	const titleBFlags=["작전담당부사관1","2중대장1","작전장교1","통신소대장1","교육화생방부사관1","작전과장1"];
	const titleCFlags=["찐퇴근"];
	let getedTitle=title;
	
	if((titleCFlags).every(sf => {
          return storyFlags[sf]})){
		getedTitle="　퇴근할 수 있는 자　";
	}
	else if((titleBFlags).every(sf => {
          return storyFlags[sf]})){
		getedTitle="　내부침해 근절자　";
	}
	else if((titleAFlags).every(sf => {
          return storyFlags[sf]})){
		getedTitle="　사보날의 달인　";
	}

	if(overWorldMap !== undefined && title !== getedTitle){
		overWorldMap.startCutscene([{type:"textMessage",text:getedTitle+"을(를) 획득하였다!!!"}]);
	}
    

        
	
	title = getedTitle;
	document.querySelector(".title").innerHTML = title;
}
checkTitle();
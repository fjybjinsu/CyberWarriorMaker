let open=0;
let move=0;
let page=1;
let click_page=1;
function ro(ele,ang){
	let eee=document.querySelector(ele);
	eee.style.transform = 'rotateY('+ang+'deg)';
}

function pre_btn(){if(page>1) page_swap(page-1);}
function next_btn(){if(page<24)page_swap((page+1));}


function page_swap(p){
	let time = page;
	if(click_page !== page) return;
	click_page = p;
	document.querySelector('.dis').style.display='none';
	if(p>page){
		for(var i = page; i<p ; i++){
			if(document.querySelector('.page_'+(i+1))===null) return;
			let ep = document.querySelector('.page_'+i);
			
			setTimeout(function(){
				page++;
				ep.style.transform = 'translate(200px,-10px)';
				setTimeout(function(){ep.style.zIndex = '-10';ep.style.transform = 'translate(0px,-10px)';
					setTimeout(function(){ep.style.display = 'none';},200);
				},200);
				
			},(time-i)*-50);
		}
	}
	else if(p<page){
		for(var i = page; i>p; i--){
			if(open==0) time=i;
			if(document.querySelector('.page_'+(i-1))===null) return;
			let ep = document.querySelector('.page_'+(i-1));
			
				ep.style.zIndex = '94';
				ep.style.display = '';
			setTimeout(function(){
				page--;
				ep.style.transform = 'translate(200px, -10px)';
				
					setTimeout(function(){ep.style.zIndex = '95';},100);
					setTimeout(function(){ep.style.transform = ''},200);
				
			},(time-i)*50);
		}
	}
	
}
let disnone = 2;
function book_move(){
	document.querySelector('.book_btn').blur();
	if(move===0){
		document.querySelector('.book').style.transform = 'translate(-660px)';
		document.querySelector('.book_btn').innerHTML='>'
		move=1;
		disnone--;
		if(disnone===0)
		    document.querySelector('.book_btn_text').style.display='none';
		
	}else{
		
		var time = 0;
		if(open===1) time =500;
		document.querySelector('.book_btn').style.left=''
		document.querySelector('.book_btn').innerHTML='<'
		
		document.querySelector('.pre_btn').style.display='';
		document.querySelector('.next_btn').style.display='';
			
		document.querySelector('.front').style.width='';
		document.querySelector('.front_back').style.width='';
		
		document.querySelector('.front_span').style.display='';
		ro('.front',0);ro('.front_back',0);
		setTimeout(function(){
			document.querySelector('.book').style.transform = '';
			page_swap(1)
			document.querySelector('.dis').style.display='block';
		},time);
		
		
		move = 0;
		open = 0;
		
	book_force = 0;
	}
}
function book_open(){
	if(open===0){
		document.querySelector('.book_btn').style.left='-60%';
		ro('.front',-140);ro('.front_back',-139.9);
		
		document.querySelector('.front_span').style.display='none';
		
		document.querySelector('.pre_btn').style.display='block';
		document.querySelector('.next_btn').style.display='block';
		
		document.querySelector('.front').style.width='60%';
		document.querySelector('.front_back').style.width='60%';
		open=1;
	}
}
document.querySelector('.book_big').style.display='none';
let book = document.querySelector('.book');
let book_big = document.querySelector('.book_big');


	let book_btn_text = document.createElement('div');
	book_btn_text.setAttribute('class','book_btn_text');
	book_btn_text.innerHTML = '<span">보안가이드<br>펼치기</span>';
	book_big.appendChild(book_btn_text);
	
var img_url = 'url("./bookContent/보안가이드_카드뉴스_1.png")';
document.querySelector('.front').style.background = img_url;
document.querySelector('.front').style.backgroundSize='600px';
document.querySelector('.front').innerHTML = '<span class="front_span">Click!!!</span>';
for(var i =24; i>= 1; i--){
	let page = document.createElement('div');
	page.setAttribute('name','paper');
	page.setAttribute('class','page_'+i);
	var img_url = 'url("./bookContent/보안가이드_카드뉴스_'+(i+1)+'.png")';
	page.innerHTML = '<span class="paper_span">-'+i+'-</span>';
	page.style.background=img_url;
	page.style.backgroundSize='600px';
	book.appendChild(page);
}
			
let page2 = document.createElement('div');

page2.setAttribute('class','paper_dumy');
book.appendChild(page2);

let l_btn = document.createElement('div');
l_btn.setAttribute('class','pre_btn');
l_btn.innerHTML = '&lt';
l_btn.addEventListener('click',pre_btn);
book.appendChild(l_btn);

let r_btn = document.createElement('div');
r_btn.setAttribute('class','next_btn');
r_btn.innerHTML = '&gt';
r_btn.addEventListener('click',next_btn);
book.appendChild(r_btn);

let f_b = document.createElement('div');
f_b.setAttribute('class','front_back');

let f_b_c = document.createElement('div');
f_b_c.setAttribute('class','front_back_center');

page_ex=['',
'목차', 					//1
'사이버 보안진단의날',		//2
'개인PC 체크리스트',			//3
'클린 스마트폰',			//4
'보안 규정평가',			//5
'비문,암호장비,c4i 점검',	//6
'필수 SW',				//7
'바이러스 백신 프로그램',		//8
'전군PC 보안체계',			//9
'전군PC 보안체계2',
'전산보안진단체계',
'보안 바탕화면',
'화면 보호기',
'기타SW',
'궁금한 사항은?',
'내부 침해 행위',
'비인가 네트워크',
'스마트폰 연결',
'바이러스 감염',
'무선 장치 탐지',
'비인가 소프트웨어',
'침해 행위',
'정보보호 실전수칙',
'끝',



]
for(var i =1; i<= 24; i++){
	let a = document.createElement('a');
	a.setAttribute('class','ahrck');
	a.setAttribute('onclick','page_swap('+i+')');
	a.innerHTML = i+'p - '+page_ex[i]+'<br>';
	f_b_c.appendChild(a);
}
f_b.appendChild(f_b_c);
book.appendChild(f_b);

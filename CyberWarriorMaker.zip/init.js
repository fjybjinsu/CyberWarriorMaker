(function () {

	var agent = navigator.userAgent.toLowerCase();
	if((navigator.appName =='Netscape' && navigator.userAgent.search('Trident')!=-1) || (agent.indexOf("msie") != -1))
		{
			alert('Internet Explorer Not Working Try to Use Chrome');
			document.body.innerHTML = '<img src="./images/NotWorking.png" style="transform:translateX(30%) translateY(25%)">';
		}
	else{
		const overworld = new Overworld({
		element: document.querySelector(".game-container")
		});
		overworld.init();
	}


})();
class Quest extends GameObject {
  constructor(config) {
    super(config);
    this.sprite = new Sprite({
      gameObject: this,
      src: "./images/characters/questdoor.png",
      animations: {
        "used-down"   : [ [1,0],[1,0],[1,0],[1,0],[1,0],[1,0], ],
        "unused-down" : [ [0,0],[0,0],[0,1],[0,2],[0,2],[0,3],] ,
      },
      currentAnimation: "used-down"
    });
    this.storyFlag = config.storyFlag;
 
  }

  update() {
   this.sprite.currentAnimation = playerState.storyFlags[this.storyFlag]
    ? "used-down"
    : "unused-down";
  }

}
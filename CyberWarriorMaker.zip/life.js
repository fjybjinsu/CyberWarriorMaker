let life=3;
function setLife(num){	
	life=num;
	
	for(var  i=1; i<=3; i++){
		let h=document.querySelector('.heart_'+i);
		h.style.display='none'
	}
	
	for(var i=1; i<=num; i++){
		let h=document.querySelector('.heart_'+i);
		h.style.display='block'
	}
	
	if(life==0){
		//게임을 종료하고 로드하는 것
		window.location.reload();
	}
}

function decreaseLife(){
	setLife(life-1);
}
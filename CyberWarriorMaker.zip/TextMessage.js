let name=0;
let book_force = 0;
class TextMessage {
  constructor({ text, onComplete }) {
    this.text = text;
    this.onComplete = onComplete;
    this.element = null;
  }

  createElement() {
    this.element = document.createElement("div");
    this.element.classList.add("TextMessage");

    this.element.innerHTML = (`
      <p class="TextMessage_p"></p>
      <button class="TextMessage_button">Next</button>
    `)

    this.revealingText = new RevealingText({
      element: this.element.querySelector(".TextMessage_p"),
      text: this.text
    })

    this.element.querySelector("button").addEventListener("click", () => {
      this.done();
    });

    this.actionListener = new KeyPressListener("Enter", () => {
      this.done();
    })

  }

  done() {
    if (this.revealingText.isDone) {
		if(book_force!==0){
			if(move==1) return;
			book_move();
			if(book_force !== -1){
				book_open();
				page_swap(book_force);
			}
			return;
		}
      this.element.remove();
      this.actionListener.unbind();
      this.onComplete();
    } else {
      this.revealingText.warpToDone();
    }
  }

  init(container) {
    this.createElement();
    container.appendChild(this.element);
    this.revealingText.init();
  }

}
function getInput(){
	name = document.querySelector('.in').value;
}
class inputTextMessage {
  constructor({ text, onComplete }) {
    this.text = text;
    this.onComplete = onComplete;
    this.element = null;
  }

  createElement() {
    //Create the element
    this.element = document.createElement("div");
    this.element.classList.add("inputTextMessage");

    this.element.innerHTML = (`
      <p class="inputTextMessage_p"></p>
	  <input type="text" class="in" onkeyup='getInput'></input>
      <button class="inputTextMessage_button">Next</button>
    `)

    //Init the typewriter effect
    this.revealingText = new RevealingText({
      element: this.element.querySelector(".inputTextMessage_p"),
      text: this.text
    })

    this.element.querySelector("button").addEventListener("click", () => {
      //Close the text message
      this.done();
    });

    this.actionListener = new KeyPressListener("Enter", () => {
      this.done();
    })

  }

  done() {
    if (this.revealingText.isDone) {
		if(document.querySelector('.in').value===''&&name==0){document.querySelector('.inputTextMessage_p').innerHTML="<b>이름을 입력해주세요</b>"; name=1; return};
		if(document.querySelector('.in').value===''&&name==1){document.querySelector('.inputTextMessage_p').innerHTML="이름을 입력해주세요"; name=0; return};
		window.playerState.storyFlags['캐릭터이름']=document.querySelector('.in').value;
      this.element.remove();
      this.actionListener.unbind();
      this.onComplete();
    } else {
      this.revealingText.warpToDone();
    }
  }

  init(container) {
    this.createElement();
    container.appendChild(this.element);
    this.revealingText.init();
  }

}
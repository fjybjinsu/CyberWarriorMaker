class OverworldMap {
  constructor(config) {
    this.overworld = null;
    this.gameObjects = config.gameObjects;
    this.cutsceneSpaces = config.cutsceneSpaces || {};
    this.walls = config.walls || {};

    this.lowerImage = new Image();
    this.lowerImage.src = config.lowerSrc;

    this.upperImage = new Image();
    this.upperImage.src = config.upperSrc;

    this.isCutscenePlaying = false;
    this.isPaused = false;
  }

  drawLowerImage(ctx, cameraPerson) {
    ctx.drawImage(
      this.lowerImage, 
      utils.withGrid(10.5) - cameraPerson.x, 
      utils.withGrid(6) - cameraPerson.y
      )
  }

  drawUpperImage(ctx, cameraPerson) {
    ctx.drawImage(
      this.upperImage, 
      utils.withGrid(10.5) - cameraPerson.x, 
      utils.withGrid(6) - cameraPerson.y
    )
  } 

  isSpaceTaken(currentX, currentY, direction) {
    const {x,y} = utils.nextPosition(currentX, currentY, direction);
    return this.walls[`${x},${y}`] || false;
  }

  mountObjects() {
    Object.keys(this.gameObjects).forEach(key => {

      let object = this.gameObjects[key];
      object.id = key;

      //TODO: determine if this object should actually mount
      object.mount(this);

    })
  }

  async startCutscene(events) {
    this.isCutscenePlaying = true;
    for (let i=0; i<events.length; i++) {
      const eventHandler = new OverworldEvent({
        event: events[i],
        map: this,
      })
      const result = await eventHandler.init();
      if (result === "UNSOLVE_QUIZ") {
        break;
      }
    }
    this.isCutscenePlaying = false;
  }

  checkForActionCutscene() {
    const hero = this.gameObjects["hero"];
    const nextCoords = utils.nextPosition(hero.x, hero.y, hero.direction);
    const match = Object.values(this.gameObjects).find(object => {
      return `${object.x},${object.y}` === `${nextCoords.x},${nextCoords.y}`
    });
    if (!this.isCutscenePlaying && match && match.talking.length) {
      const relevantScenario = match.talking.find(scenario => {
        return (scenario.required || []).every(sf => {
          return playerState.storyFlags[sf];
        })
      })
      relevantScenario && this.startCutscene(relevantScenario.events)
    }
  }

  checkForFootstepCutscene() {
    const hero = this.gameObjects["hero"];
    const match = this.cutsceneSpaces[`${hero.x},${hero.y}`];
	let nextEvent=null;
    if (!this.isCutscenePlaying && match && match.length) {
	  for(let i=0;i<match.length-1;i++){
		if((match[i].required).every((sf) => {
          return storyFlags[sf]})){
		  nextEvent=match[i].events;
		  break;
		}
	  }
	  if(nextEvent!=null){
		this.startCutscene(nextEvent);
	  }
	  else{
		this.startCutscene(match[match.length-1].events);
	  }
    }
  }

  addWall(x,y) {
    this.walls[`${x},${y}`] = true;
  }
  removeWall(x,y) {
    delete this.walls[`${x},${y}`]
  }
  moveWall(wasX, wasY, direction) {
    this.removeWall(wasX, wasY);
    const {x,y} = utils.nextPosition(wasX, wasY, direction);
    this.addWall(x,y);
  }

}

window.OverworldMaps = {
  OutSide: {
    id: "OutSide",
    lowerSrc: "./images/map/outside.png",
    upperSrc: "./images/map/empty.png",
    gameObjects: {
      spriteA: new Person({
        x: utils.withGrid(24)-3,
        y: utils.withGrid(31)+18,
        src: "./images/Outside/sprite1.png",	
		who: "object"
      }),

      spriteB: new Person({
        x: utils.withGrid(32)-2,
        y: utils.withGrid(31)+18,
        src: "./images/Outside/sprite1.png",	
		who: "object"

      }),		
      spriteC: new Person({
        x: utils.withGrid(24),
        y: utils.withGrid(33),
        src: "./images/Outside/sprite2.png",	
		who: "object"

      }),	      
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(21),
        y: utils.withGrid(39),
		direction: "right"
      }),	  
      tree1: new Person({
        x: utils.withGrid(23),
        y: utils.withGrid(22),
        src: "./images/handmade/tree4.png",	
		who: "object"

      }),
      tree2: new Person({
        x: utils.withGrid(23),
        y: utils.withGrid(18),
        src: "./images/handmade/tree3.png",	
		who: "object"
      }),
      tree4: new Person({
        x: utils.withGrid(23),
        y: utils.withGrid(13),
        src: "./images/handmade/tree5.png",	
		who: "object"

      }),	 	  
      tree3: new Person({
        x: utils.withGrid(23),
        y: utils.withGrid(15),
        src: "./images/handmade/tree.png",	
		who: "object"

      }),
      tree5: new Person({
        x: utils.withGrid(33)+7,
        y: utils.withGrid(29),
        src: "./images/handmade/tree2.png",	
		who: "object"

      }), 	
      tree6: new Person({
        x: utils.withGrid(33)+7,
        y: utils.withGrid(24),
        src: "./images/handmade/tree.png",	
		who: "object"

      }),	  
      tree7: new Person({
        x: utils.withGrid(45),
        y: utils.withGrid(14)-3,
        src: "./images/handmade/tree.png",	
		who: "object"

      }),
      tree8: new Person({
        x: utils.withGrid(48),
        y: utils.withGrid(14)-3,
        src: "./images/handmade/tree.png",	
		who: "object"

      }),	  
      sprite1: new Person({
        x: utils.withGrid(28)-8,
        y: utils.withGrid(32)+5,
        src: "./images/handmade/sprite1.png",	
		who: "object"
      }),	  	  
      sprite2: new Person({
        x: utils.withGrid(24)+9,
        y: utils.withGrid(38)-4,
        src: "./images/handmade/sprite2.png",	
		who: "object"
      }),
      sprite3: new Person({
        x: utils.withGrid(30)-5,
        y: utils.withGrid(38)-4,
        src: "./images/handmade/sprite3.png",	
		who: "object"

      }),	 
      sprite4: new Person({
        x: utils.withGrid(48)-11,
        y: utils.withGrid(26)+1,
        src: "./images/handmade/sprite4.png",	
		who: "object"

      }),
      sprite5: new Person({
        x: utils.withGrid(37)+1,
        y: utils.withGrid(22)+2,
        src: "./images/handmade/sprite5.png",	
		who: "object"

      }),	 
      sprite6: new Person({
        x: utils.withGrid(40)+4,
        y: utils.withGrid(22)+2,
        src: "./images/handmade/sprite6.png",	
		who: "object"
      }), 	  
      wall1: new Person({
        x: utils.withGrid(21),
        y: utils.withGrid(38)-4,
        src: "./images/handmade/wall1.png",	
		who: "object"

      }),	 
      wall2: new Person({
        x: utils.withGrid(16)+1,
        y: utils.withGrid(38)-4,
        src: "./images/handmade/wall2.png",	
		who: "object"

      }),	 
      wall3: new Person({
        x: utils.withGrid(32)+5,
        y: utils.withGrid(38)-4,
        src: "./images/handmade/wall3.png",	
		who: "object"

      }),
      npcA: new Person({
        x: utils.withGrid(24),
        y: utils.withGrid(32),
        src: "./images/characters/people/npcA.png",
      }),
      npcB: new Person({
        x: utils.withGrid(32),
        y: utils.withGrid(32),
        src: "./images/characters/people/npcA.png",
        talking: [
		  {	
            required:["신발"],
            events: [{type: "textMessage", text: "[초병2] : 실내에선 조심히 뛰십쇼", faceHero: "npcB"},],
		  },			
		  {	
            events: [ 
				{type: "textMessage", text: "[초병2] : 이 신발을 신고 스페이스바를 누르면서 움직이면^ 빠르게 달릴수 있습니다!", faceHero: "npcB"},
                {type: "textMessage", text: "신발을 장착했다!", faceHero: "npcB"},
				{ type: "addStoryFlag", flag: "신발"},
			],
		  },	  
        ]
      }),
      cat: new Person({
        x: utils.withGrid(25),
        y: utils.withGrid(33),
        src: "./images/Outside/cat.png",
        who : "animation_object",
      }),      
	  quest_Guardhouse: new Quest({
       x: utils.withGrid(21)-1,
       y: utils.withGrid(31)-1,
        storyFlag: "출입증",
		who:"quest",
      }),  
	  quest_Guardhouse2: new Quest({
       x: utils.withGrid(21)-1,
       y: utils.withGrid(31)-1,
        storyFlag: "찐찐퇴근",
		who:"quest",
      }),  
	quest_npcA: new Quest({
       x: utils.withGrid(27)-1,
       y: utils.withGrid(31)-1,
        storyFlag: "출입완료",
		who:"quest",
      }),	
	quest_Hall: new Quest({
       x: utils.withGrid(41)-1,
       y: utils.withGrid(6)-1,
        storyFlag: "퇴근",
		who:"quest",
      }),	
    },	
	
    walls: {
		// 바리게이트
		[utils.asGridCoord(24,33)] : true,
		
		
		[utils.asGridCoord(46,26)] : true,
		[utils.asGridCoord(47,26)] : true,
		[utils.asGridCoord(48,26)] : true,
		[utils.asGridCoord(48,26)] : true,
		
		
		
		[utils.asGridCoord(25,32)] : true,
		[utils.asGridCoord(24,37)] : true,
		[utils.asGridCoord(25,37)] : true,
		[utils.asGridCoord(28,37)] : true,
		[utils.asGridCoord(29,37)] : true,
		[utils.asGridCoord(30,37)] : true,
		[utils.asGridCoord(31,37)] : true,		
		
		[utils.asGridCoord(33,18)] : true,
		[utils.asGridCoord(33,17)] : true,
		[utils.asGridCoord(33,16)] : true,
		[utils.asGridCoord(33,15)] : true,
		[utils.asGridCoord(33,14)] : true,
		[utils.asGridCoord(33,13)] : true,
		[utils.asGridCoord(34,18)] : true,
		[utils.asGridCoord(34,17)] : true,
		[utils.asGridCoord(34,16)] : true,
		[utils.asGridCoord(34,15)] : true,
		[utils.asGridCoord(34,14)] : true,
		[utils.asGridCoord(34,13)] : true,	  
		[utils.asGridCoord(0,0)] : true,
		[utils.asGridCoord(0,43)] : true,
		[utils.asGridCoord(1,43)] : true,
		[utils.asGridCoord(2,43)] : true,
		[utils.asGridCoord(3,43)] : true,
		[utils.asGridCoord(4,43)] : true,
		[utils.asGridCoord(5,43)] : true,
		[utils.asGridCoord(6,43)] : true,
		[utils.asGridCoord(7,43)] : true,
		[utils.asGridCoord(8,43)] : true,
		[utils.asGridCoord(9,43)] : true,
		[utils.asGridCoord(10,43)] : true,
		[utils.asGridCoord(11,43)] : true,
		[utils.asGridCoord(12,43)] : true,
		[utils.asGridCoord(13,43)] : true,
		[utils.asGridCoord(14,43)] : true,
		[utils.asGridCoord(15,43)] : true,
		[utils.asGridCoord(16,43)] : true,
		[utils.asGridCoord(17,43)] : true,
		[utils.asGridCoord(18,43)] : true,
		[utils.asGridCoord(19,43)] : true,
		[utils.asGridCoord(20,43)] : true,
		[utils.asGridCoord(21,43)] : true,
		[utils.asGridCoord(22,43)] : true,
		[utils.asGridCoord(23,43)] : true,
		[utils.asGridCoord(24,43)] : true,
		[utils.asGridCoord(25,43)] : true,
		[utils.asGridCoord(26,43)] : true,
		[utils.asGridCoord(27,43)] : true,
		[utils.asGridCoord(28,43)] : true,
		[utils.asGridCoord(29,43)] : true,
		[utils.asGridCoord(30,43)] : true,
		[utils.asGridCoord(31,43)] : true,
		[utils.asGridCoord(32,43)] : true,
		[utils.asGridCoord(33,43)] : true,
		[utils.asGridCoord(34,43)] : true,
		[utils.asGridCoord(35,43)] : true,
		[utils.asGridCoord(36,43)] : true,
		[utils.asGridCoord(37,43)] : true,
		[utils.asGridCoord(38,43)] : true,
		[utils.asGridCoord(39,43)] : true,
		[utils.asGridCoord(40,43)] : true,
		[utils.asGridCoord(41,43)] : true,
		[utils.asGridCoord(42,43)] : true,
		[utils.asGridCoord(43,43)] : true,
		[utils.asGridCoord(44,43)] : true,
		[utils.asGridCoord(45,43)] : true,
		[utils.asGridCoord(46,43)] : true,
		[utils.asGridCoord(47,43)] : true,
		[utils.asGridCoord(48,43)] : true,
		[utils.asGridCoord(49,43)] : true,



		[utils.asGridCoord(33,36)] : true,
		[utils.asGridCoord(50,49)] : true,
		[utils.asGridCoord(50,48)] : true,
		[utils.asGridCoord(50,47)] : true,
		[utils.asGridCoord(50,46)] : true,
		[utils.asGridCoord(50,45)] : true,
		[utils.asGridCoord(50,44)] : true,
		[utils.asGridCoord(50,43)] : true,
		[utils.asGridCoord(50,42)] : true,
		[utils.asGridCoord(50,41)] : true,
		[utils.asGridCoord(50,40)] : true,
		[utils.asGridCoord(50,39)] : true,
		[utils.asGridCoord(50,38)] : true,
		[utils.asGridCoord(50,37)] : true,
		[utils.asGridCoord(50,36)] : true,
		[utils.asGridCoord(50,35)] : true,
		[utils.asGridCoord(50,34)] : true,
		[utils.asGridCoord(50,33)] : true,
		[utils.asGridCoord(50,32)] : true,
		[utils.asGridCoord(50,31)] : true,
		[utils.asGridCoord(50,30)] : true,
		[utils.asGridCoord(50,29)] : true,
		[utils.asGridCoord(50,28)] : true,
		[utils.asGridCoord(50,27)] : true,
		[utils.asGridCoord(50,26)] : true,
		[utils.asGridCoord(50,25)] : true,
		[utils.asGridCoord(50,24)] : true,
		[utils.asGridCoord(50,23)] : true,
		[utils.asGridCoord(50,22)] : true,
		[utils.asGridCoord(50,21)] : true,
		[utils.asGridCoord(50,20)] : true,
		[utils.asGridCoord(50,19)] : true,
		[utils.asGridCoord(50,18)] : true,
		[utils.asGridCoord(50,17)] : true,
		[utils.asGridCoord(50,16)] : true,
		[utils.asGridCoord(50,15)] : true,
		[utils.asGridCoord(50,14)] : true,
		[utils.asGridCoord(50,13)] : true,
		[utils.asGridCoord(50,12)] : true,
		[utils.asGridCoord(50,11)] : true,
		[utils.asGridCoord(50,10)] : true,
		[utils.asGridCoord(50,9)] : true,
		[utils.asGridCoord(50,8)] : true,
		[utils.asGridCoord(50,7)] : true,
		[utils.asGridCoord(50,6)] : true,
		[utils.asGridCoord(50,5)] : true,
		[utils.asGridCoord(50,4)] : true,
		[utils.asGridCoord(50,3)] : true,
		[utils.asGridCoord(50,2)] : true,
		[utils.asGridCoord(50,1)] : true,
		[utils.asGridCoord(50,0)] : true,


		[utils.asGridCoord(-1,49)] : true,
		[utils.asGridCoord(-1,48)] : true,
		[utils.asGridCoord(-1,47)] : true,
		[utils.asGridCoord(-1,46)] : true,
		[utils.asGridCoord(-1,45)] : true,
		[utils.asGridCoord(-1,44)] : true,
		[utils.asGridCoord(-1,43)] : true,
		[utils.asGridCoord(-1,42)] : true,
		[utils.asGridCoord(-1,41)] : true,
		[utils.asGridCoord(-1,40)] : true,
		[utils.asGridCoord(-1,39)] : true,
		[utils.asGridCoord(-1,38)] : true,
		[utils.asGridCoord(-1,37)] : true,
		[utils.asGridCoord(-1,36)] : true,
		[utils.asGridCoord(-1,35)] : true,
		[utils.asGridCoord(-1,34)] : true,
		[utils.asGridCoord(-1,33)] : true,
		[utils.asGridCoord(-1,32)] : true,
		[utils.asGridCoord(-1,31)] : true,
		[utils.asGridCoord(-1,30)] : true,
		[utils.asGridCoord(-1,29)] : true,
		[utils.asGridCoord(-1,28)] : true,
		[utils.asGridCoord(-1,27)] : true,
		[utils.asGridCoord(-1,26)] : true,
		[utils.asGridCoord(-1,25)] : true,
		[utils.asGridCoord(-1,24)] : true,
		[utils.asGridCoord(-1,23)] : true,
		[utils.asGridCoord(-1,22)] : true,
		[utils.asGridCoord(-1,21)] : true,
		[utils.asGridCoord(-1,20)] : true,
		[utils.asGridCoord(-1,19)] : true,
		[utils.asGridCoord(-1,18)] : true,
		[utils.asGridCoord(-1,17)] : true,
		[utils.asGridCoord(-1,16)] : true,
		[utils.asGridCoord(-1,15)] : true,
		[utils.asGridCoord(-1,14)] : true,
		[utils.asGridCoord(-1,13)] : true,
		[utils.asGridCoord(-1,12)] : true,
		[utils.asGridCoord(-1,11)] : true,
		[utils.asGridCoord(-1,10)] : true,
		[utils.asGridCoord(-1,9)] : true,
		[utils.asGridCoord(-1,8)] : true,
		[utils.asGridCoord(-1,7)] : true,
		[utils.asGridCoord(-1,6)] : true,
		[utils.asGridCoord(-1,5)] : true,
		[utils.asGridCoord(-1,4)] : true,
		[utils.asGridCoord(-1,3)] : true,
		[utils.asGridCoord(-1,2)] : true,
		[utils.asGridCoord(-1,1)] : true,
		[utils.asGridCoord(-1,0)] : true,

		[utils.asGridCoord(0,12)] : true,
		[utils.asGridCoord(1,12)] : true,
		[utils.asGridCoord(2,12)] : true,
		[utils.asGridCoord(3,12)] : true,
		[utils.asGridCoord(4,12)] : true,
		[utils.asGridCoord(5,12)] : true,
		[utils.asGridCoord(6,12)] : true,
		[utils.asGridCoord(7,12)] : true,
		[utils.asGridCoord(8,12)] : true,
		[utils.asGridCoord(9,12)] : true,
		[utils.asGridCoord(10,12)] : true,
		[utils.asGridCoord(11,12)] : true,
		[utils.asGridCoord(12,12)] : true,
		[utils.asGridCoord(13,12)] : true,
		[utils.asGridCoord(14,12)] : true,
		[utils.asGridCoord(15,12)] : true,
		[utils.asGridCoord(16,12)] : true,
		[utils.asGridCoord(17,12)] : true,
		[utils.asGridCoord(18,12)] : true,
		[utils.asGridCoord(19,12)] : true,
		[utils.asGridCoord(20,12)] : true,
		[utils.asGridCoord(21,12)] : true,
		[utils.asGridCoord(22,12)] : true,
		[utils.asGridCoord(23,13)] : true,
		[utils.asGridCoord(23,14)] : true,
		[utils.asGridCoord(23,15)] : true,
		[utils.asGridCoord(23,16)] : true,
		[utils.asGridCoord(23,17)] : true,
		[utils.asGridCoord(23,18)] : true,
		[utils.asGridCoord(23,19)] : true,
		[utils.asGridCoord(23,20)] : true,
		[utils.asGridCoord(23,21)] : true,
		[utils.asGridCoord(23,22)] : true,


		[utils.asGridCoord(23,12)] : true,
		[utils.asGridCoord(23,13)] : true,
		[utils.asGridCoord(23,10)] : true,
		[utils.asGridCoord(24,10)] : true,
		[utils.asGridCoord(25,10)] : true,
		[utils.asGridCoord(23,11)] : true,
		[utils.asGridCoord(26,9)] : true,
		[utils.asGridCoord(27,9)] : true,
		[utils.asGridCoord(28,9)] : true,
		[utils.asGridCoord(29,9)] : true,
		[utils.asGridCoord(30,9)] : true,
		[utils.asGridCoord(31,9)] : true,
		[utils.asGridCoord(32,9)] : true,
		[utils.asGridCoord(33,9)] : true,
		[utils.asGridCoord(34,9)] : true,
		[utils.asGridCoord(35,9)] : true,
		[utils.asGridCoord(36,9)] : true,
		[utils.asGridCoord(37,9)] : true,
		[utils.asGridCoord(38,9)] : true,
		[utils.asGridCoord(39,9)] : true,
		[utils.asGridCoord(39,8)] : true,
		[utils.asGridCoord(40,7)] : true,
		[utils.asGridCoord(42,7)] : true,
		[utils.asGridCoord(43,8)] : true,
		[utils.asGridCoord(43,9)] : true,
		[utils.asGridCoord(44,9)] : true,
		[utils.asGridCoord(45,9)] : true,
		[utils.asGridCoord(46,9)] : true,
		[utils.asGridCoord(47,9)] : true,
		[utils.asGridCoord(48,9)] : true,
		[utils.asGridCoord(49,9)] : true,


		[utils.asGridCoord(0,37)] : true,
		[utils.asGridCoord(1,37)] : true,
		[utils.asGridCoord(2,37)] : true,
		[utils.asGridCoord(3,37)] : true,
		[utils.asGridCoord(4,37)] : true,
		[utils.asGridCoord(5,37)] : true,
		[utils.asGridCoord(6,37)] : true,
		[utils.asGridCoord(7,37)] : true,
		[utils.asGridCoord(8,37)] : true,
		[utils.asGridCoord(9,37)] : true,
		[utils.asGridCoord(10,37)] : true,
		[utils.asGridCoord(11,37)] : true,
		[utils.asGridCoord(12,37)] : true,
		[utils.asGridCoord(13,37)] : true,
		[utils.asGridCoord(14,37)] : true,
		[utils.asGridCoord(15,37)] : true,
		[utils.asGridCoord(16,37)] : true,
		[utils.asGridCoord(17,37)] : true,
		[utils.asGridCoord(18,37)] : true,
		[utils.asGridCoord(19,37)] : true,
		[utils.asGridCoord(20,37)] : true,
		[utils.asGridCoord(21,37)] : true,
		[utils.asGridCoord(22,37)] : true,
		[utils.asGridCoord(23,37)] : true,
		[utils.asGridCoord(32,37)] : true,
		[utils.asGridCoord(33,37)] : true,
		[utils.asGridCoord(34,37)] : true,
		[utils.asGridCoord(35,37)] : true,
		[utils.asGridCoord(36,37)] : true,
		[utils.asGridCoord(37,37)] : true,
		[utils.asGridCoord(38,37)] : true,
		[utils.asGridCoord(39,37)] : true,
		[utils.asGridCoord(40,37)] : true,
		[utils.asGridCoord(41,37)] : true,
		[utils.asGridCoord(42,37)] : true,
		[utils.asGridCoord(43,37)] : true,
		[utils.asGridCoord(44,37)] : true,
		[utils.asGridCoord(45,37)] : true,
		[utils.asGridCoord(46,37)] : true,
		[utils.asGridCoord(47,37)] : true,
		[utils.asGridCoord(48,37)] : true,
		[utils.asGridCoord(49,37)] : true,
		[utils.asGridCoord(50,37)] : true,

		[utils.asGridCoord(0,31)] : true,
		[utils.asGridCoord(1,31)] : true,
		[utils.asGridCoord(2,31)] : true,
		[utils.asGridCoord(3,31)] : true,
		[utils.asGridCoord(4,31)] : true,
		[utils.asGridCoord(5,31)] : true,
		[utils.asGridCoord(6,31)] : true,
		[utils.asGridCoord(7,31)] : true,
		[utils.asGridCoord(8,31)] : true,
		[utils.asGridCoord(9,31)] : true,
		[utils.asGridCoord(10,31)] : true,
		[utils.asGridCoord(11,31)] : true,
		[utils.asGridCoord(12,31)] : true,
		[utils.asGridCoord(13,31)] : true,
		[utils.asGridCoord(14,27)] : true,
		[utils.asGridCoord(14,28)] : true,
		[utils.asGridCoord(14,29)] : true,
		[utils.asGridCoord(14,30)] : true,
		[utils.asGridCoord(14,31)] : true,
		[utils.asGridCoord(14,32)] : true,
		[utils.asGridCoord(14,33)] : true,
		[utils.asGridCoord(14,34)] : true,
		[utils.asGridCoord(14,35)] : true,
		[utils.asGridCoord(14,36)] : true,
		[utils.asGridCoord(14,37)] : true,
		[utils.asGridCoord(15,27)] : true,
		[utils.asGridCoord(16,27)] : true,
		[utils.asGridCoord(17,27)] : true,
		[utils.asGridCoord(18,27)] : true,
		[utils.asGridCoord(19,27)] : true,
		[utils.asGridCoord(20,27)] : true,
		[utils.asGridCoord(21,27)] : true,
		[utils.asGridCoord(22,27)] : true,
		[utils.asGridCoord(23,27)] : true,
		[utils.asGridCoord(23,26)] : true,
		[utils.asGridCoord(23,25)] : true,
		[utils.asGridCoord(23,27)] : true,
		[utils.asGridCoord(23,28)] : true,
		[utils.asGridCoord(23,29)] : true,
		[utils.asGridCoord(23,31)] : true,
		[utils.asGridCoord(22,30)] : true,
		[utils.asGridCoord(22,31)] : true,
		[utils.asGridCoord(23,32)] : true,

		[utils.asGridCoord(22,32)] : true,
		[utils.asGridCoord(20,32)] : true,
		[utils.asGridCoord(19,32)] : true,
		[utils.asGridCoord(18,32)] : true,
		[utils.asGridCoord(17,32)] : true,
		[utils.asGridCoord(16,32)] : true,
		[utils.asGridCoord(15,32)] : true,


		[utils.asGridCoord(33,35)] : true,
		[utils.asGridCoord(33,34)] : true,
		[utils.asGridCoord(33,33)] : true,
		[utils.asGridCoord(33,32)] : true,
		[utils.asGridCoord(33,31)] : true,
		[utils.asGridCoord(33,30)] : true,
		[utils.asGridCoord(33,29)] : true,
		[utils.asGridCoord(33,28)] : true,
		[utils.asGridCoord(33,27)] : true,
		[utils.asGridCoord(33,26)] : true,
		[utils.asGridCoord(33,25)] : true,
		[utils.asGridCoord(33,24)] : true,
		[utils.asGridCoord(33,23)] : true,
		[utils.asGridCoord(33,22)] : true,
		[utils.asGridCoord(34,22)] : true,
		[utils.asGridCoord(35,22)] : true,
		[utils.asGridCoord(35,23)] : true,
		[utils.asGridCoord(37,22)] : true,


		[utils.asGridCoord(39,22)] : true,
		[utils.asGridCoord(39,23)] : true,
		[utils.asGridCoord(38,23)] : true,
		[utils.asGridCoord(37,23)] : true,
		[utils.asGridCoord(36,23)] : true,

		[utils.asGridCoord(40,22)] : true,
		[utils.asGridCoord(40,23)] : true,
		[utils.asGridCoord(34,24)] : true,
		[utils.asGridCoord(34,25)] : true,
		[utils.asGridCoord(34,26)] : true,
		[utils.asGridCoord(35,27)] : true,
		[utils.asGridCoord(36,27)] : true,
		[utils.asGridCoord(37,27)] : true,
		[utils.asGridCoord(38,27)] : true,
		[utils.asGridCoord(39,27)] : true,
		[utils.asGridCoord(40,27)] : true,
		[utils.asGridCoord(40,28)] : true,
		[utils.asGridCoord(40,29)] : true,
		[utils.asGridCoord(40,30)] : true,
		[utils.asGridCoord(41,30)] : true,
		[utils.asGridCoord(42,30)] : true,
		[utils.asGridCoord(43,30)] : true,
		[utils.asGridCoord(44,30)] : true,
		[utils.asGridCoord(45,30)] : true,
		[utils.asGridCoord(46,30)] : true,
		[utils.asGridCoord(47,30)] : true,
		[utils.asGridCoord(48,30)] : true,
		[utils.asGridCoord(49,30)] : true,




		[utils.asGridCoord(49,13)] : true,
		[utils.asGridCoord(48,13)] : true,
		[utils.asGridCoord(47,13)] : true,
		[utils.asGridCoord(46,13)] : true,
		[utils.asGridCoord(45,13)] : true,
		[utils.asGridCoord(44,13)] : true,
		[utils.asGridCoord(43,13)] : true,
		[utils.asGridCoord(42,13)] : true,
		[utils.asGridCoord(41,13)] : true,
		[utils.asGridCoord(40,13)] : true,
		[utils.asGridCoord(39,13)] : true,
		[utils.asGridCoord(38,13)] : true,
		[utils.asGridCoord(37,13)] : true,
		[utils.asGridCoord(36,13)] : true,
		[utils.asGridCoord(35,13)] : true,
		[utils.asGridCoord(34,13)] : true,
		[utils.asGridCoord(33,13)] : true,   
		[utils.asGridCoord(33,14)] : true,
		[utils.asGridCoord(33,15)] : true,
		[utils.asGridCoord(33,16)] : true,
		[utils.asGridCoord(33,17)] : true,
		[utils.asGridCoord(34,17)] : true,
		[utils.asGridCoord(35,17)] : true,
		[utils.asGridCoord(36,17)] : true,
		[utils.asGridCoord(37,17)] : true,
		[utils.asGridCoord(38,17)] : true,
		[utils.asGridCoord(39,17)] : true,
		[utils.asGridCoord(40,17)] : true,
		[utils.asGridCoord(41,17)] : true,
		[utils.asGridCoord(42,17)] : true,
		[utils.asGridCoord(43,17)] : true,
		[utils.asGridCoord(44,17)] : true,
		[utils.asGridCoord(45,17)] : true,
		[utils.asGridCoord(46,17)] : true,
		[utils.asGridCoord(46,16)] : true,
		[utils.asGridCoord(46,15)] : true,
		[utils.asGridCoord(47,14)] : true,
		[utils.asGridCoord(48,14)] : true,
		[utils.asGridCoord(49,14)] : true,
		[utils.asGridCoord(50,14)] : true,

		[utils.asGridCoord(32,33)] : true,
		[utils.asGridCoord(31,33)] : true,
    },
	
    cutsceneSpaces: {
	  [utils.asGridCoord(26,38)]: [
	  {
		  required : ["퇴근"],
		  events: [
			{ type: "textMessage", text:"(위병소를 들려 보안담당관을 만나고 가자)"},
			{ who: "hero", type: "walk",  direction: "up"},
			{ who: "hero", type: "walk",  direction: "up"},	
		  ]
	  },
	  {
		  events: []					
	  },
	  ],
	  [utils.asGridCoord(27,38)]: [
	  {
		  required : ["퇴근"],
		  events: [
			{ type: "textMessage", text:"(위병소를 들려 보안담당관을 만나고 가자)"},
			{ who: "hero", type: "walk",  direction: "up"},		
			{ who: "hero", type: "walk",  direction: "up"},	
		  ]
	  },

	  {
		  events: []					
	  },
	  
	  ],
      [utils.asGridCoord(27,32)]: [
		{ 
			required : ["퇴근위병소로"],
			events: []
		},
		{ 
			required : ["퇴근"],
			events: [{ type: "textMessage", text:"충성! 수고하셨습니다. 가시기전에 위병소에 들러 보안담당관을 만나주시기 바랍니다."},
			{ who: "hero", type: "walk",  direction: "down", time: 500 },
			{ type: "addStoryFlag", flag: "퇴근위병소로"},]
		},
		{
			required : ["출입증"],
			events: [
			{ type: "addStoryFlag", flag: "출입완료"},
			{ who: "npcA", type: "walk",  direction: "up", time: 200 },
			{ who: "npcA", type: "walk",  direction: "right", time: 500 },
			{ who: "npcA", type: "stand",  direction: "down" },
			{ type: "textMessage", text:"본청은 길을 따라 직진하셔서 공사장 우측 건물로 들어가시면 됩니다."},
			{ who: "npcA", type: "walk",  direction: "left", time: 500 },	
			{ who: "npcA", type: "walk",  direction: "down", time: 200 },	    
			{ who: "hero", type: "walk",  direction: "up", time: 500 },
            { type: "textMessage", text:"( 본청 건물로 가자 )"},
			]
		   
		},
        {
          events: [
            { who: "npcA", type: "walk",  direction: "up", time: 200 },
            { who: "npcA", type: "walk",  direction: "right", time: 500 },
			{ who: "npcA", type: "stand",  direction: "down" },
            { type: "textMessage", text:"좌측에 있는 위병소에 들려서 출입신청을 해주시기 바랍니다."},

			{ who: "hero", type: "walk",  direction: "down", time: 500 },
            { who: "npcA", type: "walk",  direction: "left", time: 500 },	
            { who: "npcA", type: "walk",  direction: "down", time: 200 },				

          ]
        }
      ],	
      [utils.asGridCoord(26,32)]: [
		{ 
			required : ["퇴근위병소로"],
			events: []
		},
		{ 
			required : ["퇴근"],
			events: [{ type: "textMessage", text:"충성! 수고하셨습니다. 가시기전에 위병소에 들러 보안담당관을 만나주시기 바랍니다."},
			{ who: "hero", type: "walk",  direction: "down", time: 500 },
			{ type: "addStoryFlag", flag: "퇴근위병소로"},]
		},
		{
			required : ["출입증"],
			events: [
			{ type: "addStoryFlag", flag: "출입완료"},
			{ who: "npcA", type: "walk",  direction: "up", time: 200 },
			{ who: "npcA", type: "walk",  direction: "right", time: 500 },
			{ who: "npcA", type: "stand",  direction: "down" },
			{ type: "textMessage", text:"본청은 길을 따라 직진하셔서 공사장 우측 건물로 들어가시면 됩니다. "},
			{ who: "npcA", type: "walk",  direction: "left", time: 500 },	
			{ who: "npcA", type: "walk",  direction: "down", time: 200 },	    
			{ who: "hero", type: "walk",  direction: "up", time: 500 },       
			{ type: "textMessage", text:"( 본청 건물로 가자 )"},				
			]
		   
		},
        {
          events: [
            { who: "npcA", type: "walk",  direction: "up", time: 200 },
            { who: "npcA", type: "walk",  direction: "right", time: 500 },
			{ who: "npcA", type: "stand",  direction: "down" },
            { type: "textMessage", text:"좌측에 있는 위병소에 들려서 출입신청을 해주시기 바랍니다."},

			{ who: "hero", type: "walk",  direction: "down", time: 500 },
            { who: "npcA", type: "walk",  direction: "left", time: 500 },	
            { who: "npcA", type: "walk",  direction: "down", time: 200 },				

          ]
        }
      ],		
		
      [utils.asGridCoord(28,32)]: [
		{ 
			required : ["퇴근위병소로"],
			events: []
		},
		{ 
			required : ["퇴근"],
			events: [{ type: "textMessage", text:"충성! 수고하셨습니다. 가시기전에 위병소에 들러 보안담당관을 만나주시기 바랍니다."},
			{ who: "hero", type: "walk",  direction: "down", time: 500 },
			{ type: "addStoryFlag", flag: "퇴근위병소로"},]
		},
		{
			required : ["출입증"],
			events: [
			{ type: "addStoryFlag", flag: "출입완료"},
			{ who: "npcA", type: "walk",  direction: "up", time: 200 },
			{ who: "npcA", type: "walk",  direction: "right", time: 500 },
			{ who: "npcA", type: "stand",  direction: "down" },
			{ type: "textMessage", text:"본청은 길을 따라 직진하셔서 공사장 우측 건물로 들어가시면 됩니다. "},
			{ who: "npcA", type: "walk",  direction: "left", time: 500 },	
			{ who: "npcA", type: "walk",  direction: "down", time: 200 },	    
			{ who: "hero", type: "walk",  direction: "up", time: 500 },       
			{ type: "textMessage", text:"( 본청 건물로 가자 )"},				
			]
		   
		},
        {
          events: [
            { who: "npcA", type: "walk",  direction: "up", time: 200 },
            { who: "npcA", type: "walk",  direction: "right", time: 500 },
			{ who: "npcA", type: "stand",  direction: "down" },
            { type: "textMessage", text:"좌측에 있는 위병소에 들려서 출입신청을 해주시기 바랍니다."},

			{ who: "hero", type: "walk",  direction: "down", time: 500 },
            { who: "npcA", type: "walk",  direction: "left", time: 500 },	
            { who: "npcA", type: "walk",  direction: "down", time: 200 },				

          ]
        }
      ],		
		
      [utils.asGridCoord(29,32)]: [
		{ 
			required : ["퇴근위병소로"],
			events: []
		},
		{ 
			required : ["퇴근"],
			events: [{ type: "textMessage", text:"충성! 수고하셨습니다. 가시기전에 위병소에 들러 보안담당관을 만나주시기 바랍니다."},
			{ who: "hero", type: "walk",  direction: "down", time: 500 },
			{ type: "addStoryFlag", flag: "퇴근위병소로"},]
		},
		{
			required : ["출입증"],
			events: [
			{ type: "addStoryFlag", flag: "출입완료"},
			{ who: "npcA", type: "walk",  direction: "up", time: 200 },
			{ who: "npcA", type: "walk",  direction: "right", time: 500 },
			{ who: "npcA", type: "stand",  direction: "down" },
			{ type: "textMessage", text:"본청은 길을 따라 직진하셔서 공사장 우측 건물로 들어가시면 됩니다."},
			{ who: "npcA", type: "walk",  direction: "left", time: 500 },	
			{ who: "npcA", type: "walk",  direction: "down", time: 200 },	    
			{ who: "hero", type: "walk",  direction: "up", time: 500 },       
			{ type: "textMessage", text:"( 본청 건물로 가자 )"},				

			]
		   
		},
        {
          events: [
            { who: "npcA", type: "walk",  direction: "up", time: 200 },
            { who: "npcA", type: "walk",  direction: "right", time: 500 },
			{ who: "npcA", type: "stand",  direction: "down" },
            { type: "textMessage", text:"좌측에 있는 위병소에 들려서 출입신청을 해주시기 바랍니다."},

			{ who: "hero", type: "walk",  direction: "down", time: 500 },
            { who: "npcA", type: "walk",  direction: "left", time: 500 },	
            { who: "npcA", type: "walk",  direction: "down", time: 200 },				

          ]
        }
      ],		
		
      [utils.asGridCoord(30,32)]: [
		{ 
			required : ["퇴근위병소로"],
			events: []
		},
		{ 
			required : ["퇴근"],
			events: [{ type: "textMessage", text:"충성! 수고하셨습니다. 가시기전에 위병소에 들러 보안담당관을 만나주시기 바랍니다."},
			{ who: "hero", type: "walk",  direction: "down", time: 500 },
			{ type: "addStoryFlag", flag: "퇴근위병소로"},]
		},
		{
			required : ["출입증"],
			events: [
			{ type: "addStoryFlag", flag: "출입완료"},
			{ who: "npcA", type: "walk",  direction: "up", time: 200 },
			{ who: "npcA", type: "walk",  direction: "right", time: 500 },
			{ who: "npcA", type: "stand",  direction: "down" },
			{ type: "textMessage", text:"길을 따라 직진하셔서 공사장 우측 건물로 들어가시면 됩니다."},
			{ who: "npcA", type: "walk",  direction: "left", time: 500 },	
			{ who: "npcA", type: "walk",  direction: "down", time: 200 },	    
			{ who: "hero", type: "walk",  direction: "up", time: 500 },       
			{ type: "textMessage", text:"( 본청 건물로 가자 )"},				
			
			]
		   
		},
        {
          events: [
            { who: "npcA", type: "walk",  direction: "up", time: 200 },
            { who: "npcA", type: "walk",  direction: "right", time: 500 },
			{ who: "npcA", type: "stand",  direction: "down" },
            { type: "textMessage", text:"좌측에 있는 위병소에 들려서 출입신청을 해주시기 바랍니다. "},

			{ who: "hero", type: "walk",  direction: "down", time: 500 },
            { who: "npcA", type: "walk",  direction: "left", time: 500 },	
            { who: "npcA", type: "walk",  direction: "down", time: 200 },				

          ]
        }
      ],				
      [utils.asGridCoord(21,32)]: [
        {
          events: [
            { 
              type: "changeMap", 
              map: "Guardhouse",
              x: utils.withGrid(13),
              y: utils.withGrid(10), 
              direction: "up"
            }
          ]
        }
      ],
      [utils.asGridCoord(41,8)]: [
	    {
			required:["퇴근"],
			events: [
            { 
              type: "changeMap", 
              map: "Hall2",
              x: utils.withGrid(14),
              y: utils.withGrid(8), 
              direction: "up"
            }
          ]
		},
        {
          events: [
	{ type: "addStoryFlag", flag :"지휘통제실로"},
            { 
              type: "changeMap", 
              map: "Hall",
              x: utils.withGrid(14),
              y: utils.withGrid(9), 
              direction: "up"
            }
          ]
        }
      ],
    }
  },
  Guardhouse: {
    id: "Guardhouse",
    lowerSrc: "./images/map/guardhouse.png",
    upperSrc: "./images/map/empty.png",
    gameObjects: {
				
    hero: new Person({ 
        isPlayerControlled: true,
        x: utils.withGrid(5),
        y: utils.withGrid(6),
      }),
    npcC: new Person({
        x: utils.withGrid(10),
        y: utils.withGrid(9),
        src: "./images/characters/people/npcB.png",
      }),
      
	npcB: new Person({
        x: utils.withGrid(11),
        y: utils.withGrid(9),
        direction: "down",
        src: "./images/Guardhouse/npc.png",
        who:"animation_object",
      }), 
    sprite1: new Person({
       x: utils.withGrid(11)-10,
       y: utils.withGrid(9)+9,
       src: "./images/Guardhouse/sprite1.png",	
	who: "object"
	
     }),   
    sprite1: new Person({
       x: utils.withGrid(11)-10,
       y: utils.withGrid(9)+9,
       src: "./images/Guardhouse/sprite1.png",	
	who: "object"
	
     }), 
    sprite2: new Person({
       x: utils.withGrid(14),
       y: utils.withGrid(10),
       src: "./images/Guardhouse/sprite2.png",	
	who: "object"
	
     }),   	 
    npcA: new Person({
        x: utils.withGrid(9),
        y: utils.withGrid(5),
		direction: "down",
        src: "./images/characters/people/보안담당관.png",
        talking: [
		  {	
            required:["찐퇴근"],
            events: [ 
				{type: "textMessage", text: "[보안담당관] : 오늘 하루도 고생 많으셨습니다!", faceHero: "npcA"},
				{type: "textMessage", text: "(오늘 일과가 끝났다. 퇴근하자!)", faceHero: "npcA"},
			],
		  },			
		  {	
            required:["출입증"],
            events: [ 
				{type: "textMessage", text: "(위병소를 나가서 본청건물로 가자.)", faceHero: "npcA"},
			],
		  },	  
        ]		
      }),	
	quest_npcA: new Quest({
       x: utils.withGrid(9)-1,
       y: utils.withGrid(4)-1,
        storyFlag: "출입증",
		who:"quest",
      }),	  
	quest_npc: new Quest({
       x: utils.withGrid(9)-1,
       y: utils.withGrid(4)-1,
        storyFlag: "찐찐퇴근",
		who:"quest",
      }),	  
    },	

    walls: {
	  [utils.asGridCoord(14,8)] : true,
	  [utils.asGridCoord(14,7)] : true,	  
      [utils.asGridCoord(0,0)] : true,
      [utils.asGridCoord(0,0)] : true,
      [utils.asGridCoord(14,11)] : true,
      [utils.asGridCoord(15,11)] : true,
      [utils.asGridCoord(15,11)] : true,
      [utils.asGridCoord(15,10)] : true,
      [utils.asGridCoord(15,9)] : true,
      [utils.asGridCoord(15,8)] : true,
      [utils.asGridCoord(15,7)] : true,
      [utils.asGridCoord(15,6)] : true,
      [utils.asGridCoord(15,5)] : true,
      [utils.asGridCoord(15,4)] : true,
      [utils.asGridCoord(15,3)] : true,
      [utils.asGridCoord(14,4)] : true,
      [utils.asGridCoord(13,4)] : true,
      [utils.asGridCoord(12,4)] : true,
      [utils.asGridCoord(11,4)] : true,
      [utils.asGridCoord(10,4)] : true,
      [utils.asGridCoord(9,4)] : true,
      [utils.asGridCoord(8,4)] : true,
      [utils.asGridCoord(7,4)] : true,
      [utils.asGridCoord(6,4)] : true,
      [utils.asGridCoord(5,4)] : true,
      [utils.asGridCoord(4,4)] : true,
      [utils.asGridCoord(4,5)] : true,
      [utils.asGridCoord(4,6)] : true,
      [utils.asGridCoord(4,7)] : true,
      [utils.asGridCoord(4,8)] : true,
      [utils.asGridCoord(4,9)] : true,
      [utils.asGridCoord(4,10)] : true,
      [utils.asGridCoord(5,11)] : true,
      [utils.asGridCoord(6,11)] : true,
      [utils.asGridCoord(7,11)] : true,
      [utils.asGridCoord(8,11)] : true,
      [utils.asGridCoord(8,10)] : true,
      [utils.asGridCoord(9,11)] : true,
      [utils.asGridCoord(9,10)] : true,
      [utils.asGridCoord(10,11)] : true,
      [utils.asGridCoord(10,10)] : true,
      [utils.asGridCoord(11,11)] : true,
      [utils.asGridCoord(11,10)] : true,
      [utils.asGridCoord(12,11)] : true,
      [utils.asGridCoord(12,10)] : true,
    },
    
    cutsceneSpaces: {
	  [utils.asGridCoord(13,9)]:[
	  
	  {
		  required:["찐퇴근"],
		  events: [{type:"EndingCredit"}],
	  },	  
	  
	  {	
		required:["퇴근"],
		events: [ 	
					{ who: "hero", type:"walk", direction:"up"},
					{ who: "hero", type:"walk", direction:"up"},
					{ who: "hero", type:"walk", direction:"left"},
					{ who: "hero", type:"walk", direction:"left"},
					{ who: "hero", type:"walk", direction:"left"},
					{ who: "hero", type:"walk", direction:"left"},
					{ who: "hero", type:"walk", direction:"up"},
					{type: "textMessage", text: "[보안담당관] : 오늘 하루도 고생 많으셨습니다!", faceHero: "npcA"},
					{type: "textMessage", text: "[$name] : 아닙니다 오늘 정말 많이 배웠습니다.", faceHero: "npcA"},
					{type: "textMessage", text: "[보안담당관] : 퇴근 준비는다 하셨습니까?", faceHero: "npcA"},
					{type: "textMessage", text: "[$name] : 넵! 사무실 보안 일일결산도 했고 ^사무실 정리 및 서랍 잠금도 모두 실시했습니다.", faceHero: "npcA",book:23},
					{type: "textMessage", text: "[보안담당관] : 요즘 군 내/외부적으로 사이버보안에 ^대한 중요성이 더 올라가고 있습니다!!", faceHero: "npcA"},
					{type: "textMessage", text: "[보안담당관] : 긴장의 끈을 놓치 마시고 퇴근하셔서도 정보보호에 신경써주십시오! 충성!", faceHero: "npcA"},
					{type: "textMessage", text: "[$name] : 네 알겠습니다. 지금 당장 여기서 사소한 것부터 신경 쓰겠습니다. ^오늘 하루도 고생 많으셨습니다! 충성!", faceHero: "npcA"},
					
					{ who: "hero", type:"walk", direction:"down"},
					{type: "textMessage", text: "퇴근이다! 집으로가자(위병소를 나가자)", faceHero: "npcA"},
					{type: "addStoryFlag", flag: "찐퇴근"}
				
				],
	  },

	  {
		  required:["출입증"],
		  events: [],
	  },
	  
	  {
		  required:["시작"],
		  events: [
			{ type: "addStoryFlag", flag: "출입증"},
            { type: "addStoryFlag", flag: "찐찐퇴근"},
		    { who: "hero", type:"walk", direction:"up", time:200},
			
			{ who: "npcA", type:"stand", direction:"down"},
			{ type: "textMessage", text: "[???]: !", faceHero: "npcA" },
			{ who: "npcA", type:"walk", direction:"down"},
			{ who: "npcA", type:"walk", direction:"down"},
			{ who: "npcA", type:"walk", direction:"down"},
			{ who: "npcA", type:"walk", direction:"right"},
			{ who: "npcA", type:"walk", direction:"right"},
			{ who: "npcA", type:"walk", direction:"right"},
			{ who: "hero", type:"stand", direction:"left"},
			{ type: "textMessage", text: "[보안담당관] : 안녕하세요, 저희 부대에는 무슨 일이시죠?", faceHero: "npcA" },
			{ type: "textMessage", text: "[$name] : 고생이 많으십니다! 이번에 전입온 $name 라고 합니다"},
			{ type: "textMessage", text: "[보안담당관] : 충성! 사실 기다리고 있었습니다. 저는 이 부대의 보안 담당관입니다"},
			{ type: "textMessage", text: "[$name] : 네! 감사합니다, 잘 부탁드립니다."},
			{ type: "textMessage", text: "[보안담당관] : 먼저 ‘국방 모바일 보안’ 어플리케이션 부터 설치하시면 됩니다."},
			{ type: "textMessage", text: "[$name] : 설치 완료하였습니다"},
			{ type: "textMessage", text: "[보안담당관] : 그럼 이제 본격적으로 시작하겠습니다,  ^먼저 여기 전입간부를 위한 ‘사이버보안 가이드’ 먼저 받으십쇼!"},
			{ type: "textMessage", text: "(전입 간부를 위한 ‘사이버 보안 가이드’를 획득했다! )"},
			{ type: "addStoryFlag", flag: "사이버보안가이드"},
			{ type: "textMessage", text: " **(마우스로만 가능) 사이버보안 가이드는 화면의 오른쪽 [<] 버튼을 눌러 펼치고 ^[>] 버튼을 눌러서 접을수 있습니다.  **",book:-1},
			{ type: "textMessage", text: "[$name] : (휴.. 새로운 부대, 새로운 시작이네..!!^행정반부터 들려서 중대 간부들한테 인사부터 드리자!)"},
            { type: "textMessage", text: "[$name] : 일단 위병소를 나가서 본청으로 가보자"},
			{ type: "delStoryFlag", flag: "출입완료"},
			
			
			
			

			{ who: "npcA", type:"walk", direction:"up"},
			{ who: "npcA", type:"walk", direction:"up"},
			{ who: "npcA", type:"walk", direction:"up"},
			{ who: "npcA", type:"walk", direction:"left"},
			{ who: "npcA", type:"walk", direction:"left"},
			{ who: "npcA", type:"walk", direction:"left"},
			{ who: "npcA", type:"stand", direction:"down"},
		  ],
		  
		  
	  },	  
	  {
		required:["퇴근"],
		events: [
			{ type: "textMessage", text: "(보안담당관을 찾아가자)" ,faceHero: "npcA" },
			{ type: "addStoryFlag", flag: "보안담당관찾기"},
		],
	  },
	  ],
		
		
      [utils.asGridCoord(13,11)]: [
        {
          events: [
            { 
              type: "changeMap",
              map: "OutSide",
              x: utils.withGrid(21),
              y: utils.withGrid(33), 
              direction: "down"
            }
          ]
        }
      ]
    }
  },  
  CommandCenter: {
    id: "CommandCenter",
    lowerSrc: "./images/map/commandCenter.png",
    upperSrc: "./images/map/empty.png",
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(13),
        y: utils.withGrid(13),
      }),
	  computers: new Person({
        x: utils.withGrid(15)-10,
        y: utils.withGrid(4)+2,
        src: "./images/CommandCenter/computers.png",
        who: "animation_object",
        behaviorLoop: [
          { type: "stand", direction: "down", },
        ],
      }),
      sprite1: new Person({
        x: utils.withGrid(15)+2,
        y: utils.withGrid(8),
        src: "./images/CommandCenter/sprite1.png",	
		who: "object"

      }), 	   
      sprite2: new Person({
        x: utils.withGrid(9)+9,
        y: utils.withGrid(10)+9,
        src: "./images/CommandCenter/sprite2.png",	
		who: "object"

      }), 	       
      sprite3: new Person({
        x: utils.withGrid(15)+4,
        y: utils.withGrid(6)-11,
        src: "./images/CommandCenter/sprite3.png",	
		who: "object"

      }), 	      
      
	  npcOperationsBusaguan: new Person({	//작전담당부사관
        x: utils.withGrid(9),
        y: utils.withGrid(7),
		src: "./images/characters/people/지통실1.png",
		behaviorLoop: [
          { who: "npcOperationsBusaguan", type: "stand",  direction: "right" },
        ],
		talking: [
		  {
            required:["작전담당부사관1","2중대장1","작전장교1","통신소대장1","교육화생방부사관1","작전과장1"],
            events:[
            {type : "textMessage", text:"(인사를 다 드렸으니 밖으로 가보자)"},
            ]
          },
          {
            required:["작전담당부사관1"],
            events:[
            { type : "textMessage", text:"도와줘서 고맙습니다. 다른 분들께 인사하러 가보세요.", faceHero:"npcOperationsBusaguan"},
			{ who: "npcOperationsBusaguan", type: "stand",  direction: "right" },
            ]
          },
          {
            events: [

              { type: "textMessage", text: "[작전담당부사관] : 새로 오신 간부님! 저 좀 도와주십쇼!!", faceHero:"npcOperationsBusaguan"},
			  { type: "textMessage", text: "[$name] : 네, 제가 도와드릴 수 있는 일이 있습니까?", faceHero:"npcOperationsBusaguan"},
              { type: "textMessage", text: "[작전담당부사관] : ATCIS에 LAN선을 연결하려고 하는데 LAN선 색깔이 ^너무 다양해서 무슨 색을 꽂아야할 지 모르겠습니다 .. 혹시 기억나십니까?", faceHero:"npcOperationsBusaguan"},
			  { type: "textMessage", text: "[$name] : ATCIS는 파란색 선로에 노란색 보호캡입니다!! ", faceHero:"npcOperationsBusaguan"},
			  { type: "textMessage", text: "[작전담당부사관] : 감사합니다! 혹시 다른 망들은 알고 계십니까? ", faceHero:"npcOperationsBusaguan"},
              { type: "delStoryFlag", flag :"작전담당부사관1"},
			  { type: "QuizMessage", text: "다음 중, 선로 색깔과 보호캡 색깔이 제대로 연결되지 않은 것은?(사이버보안 가이드 17페이지를 참고하면 좋을 것 같다!)", faceHero:"npcOperationsBusaguan",
			  option:["국방망 : 회색 선, 파란색 보호캡","ATCIS : 파란색 선, 노란색 보호캡","KJCCS : 파란색 선, 파란색 보호캡","AKJCCS : 보라색 선, 파란색 보호캡"],ans:0,},
			  { type: "addStoryFlag", flag :"작전담당부사관1"},
			  { type: "textMessage", text: "[작전담당부사관] : 그걸 다 기억하고 계시다니! 정말 대단하십니다!", faceHero:"npcOperationsBusaguan"},
			  { who: "npcOperationsBusaguan", type: "stand",  direction: "right" },
            ]
          }
        ]
      }),
	  
	  npc2CompanyCommander: new Person({	//2중대장
        x: utils.withGrid(9),
        y: utils.withGrid(9),
		src: "./images/characters/people/지통실2.png",
		behaviorLoop: [
          { type: "stand", direction: "right"},
        ],
		talking: [
		  {
            required:["작전담당부사관1","2중대장1","작전장교1","통신소대장1","교육화생방부사관1","작전과장1"],
            events:[
            {type : "textMessage", text:"(인사를 다 드렸으니 밖으로 가보자)"},
            ]
          },
          {
            required:["2중대장1"],
            events:[
            {type : "textMessage", text:"도와줘서 고맙습니다. 다른 분들께 인사하러 가보세요.", faceHero:"npc2CompanyCommander"},
			{ who: "npc2CompanyCommander", type: "stand",  direction: "right" },
            ]
          },
          {
            events: [

              { type: "textMessage", text: "[2중대장] : 작전장교야! 나 충전기 좀 빌려줘!", faceHero:"npc2CompanyCommander"},
			  { type: "textMessage", text: "[$name] : 충성! 중대장님 안녕하십니까, 이번에 새로 전입 온 $name입니다.", faceHero:"npc2CompanyCommander"},
              { type: "textMessage", text: "[2중대장] : 충전이 급한데.. 어?! 새로 전입오신 $name 이십니까, 반갑습니다. ", faceHero:"npc2CompanyCommander"},
			  { type: "textMessage", text: "[2중대장] : 찾았다! 여기 케이블이 있네 .. 콘센트가 없으니 그냥 PC에 꽂아야 겠다! ", faceHero:"npc2CompanyCommander"},
              { type: "delStoryFlag", flag :"2중대장1"}, 
			  { type: "QuizMessage", text: "문제) 2중대장의 행동 중 적절하지 못한 행동은?(사이버보안 가이드 18페이지를 같이보면 좋을 것 같다!)", faceHero:"npc2CompanyCommander",
			  option:["1. 작전장교에게 충전기를 달라고 하는 행위(병영생활 부조리)",
			  "2. 분리 가능한 충전 케이블을 PC에 연결하는 행위",
			  "3. 출근해서 휴대폰을 충전하는 행위(전기 도둑?!)",
			  "4. 본인 사무실이 아니라 다른 곳에서 휴대폰을 충전하는 행위"]
			  ,ans:1,},
             
			  { type: "addStoryFlag", flag :"2중대장1"},
			  { type: "textMessage", text: "[$name] : 중대장님 제가 충전기 하나 드리겠습니다! ^그거 사용하시면 될 거 같습니다!", faceHero:"npc2CompanyCommander"},
			  { who: "npc2CompanyCommander", type: "stand",  direction: "right" },
            ]
          }
        ]
      }),
	  
	  npcOperationOfficer: new Person({	//작전장교
        x: utils.withGrid(9),
        y: utils.withGrid(11),
		src: "./images/characters/people/지통실3.png",
		behaviorLoop: [
          { type: "stand", direction: "right", time: 1000,},
        ],
		talking: [
		  {
            required:["작전담당부사관1","2중대장1","작전장교1","통신소대장1","교육화생방부사관1","작전과장1"],
            events:[
            {type : "textMessage", text:"(인사를 다 드렸으니 밖으로 가보자)"},
            ]
          },
          {
            required:["작전장교1"],
            events:[
            {type : "textMessage", text:"도와줘서 고맙습니다. 다른 분들께 인사하러 가보세요.", faceHero:"npcOperationOfficer"},
			{ who: "npcOperationOfficer", type: "stand",  direction: "right" },
            ]
          },
          {
            events: [

              { type: "textMessage", text: "[작전장교] : 휴 이거 CD 만들기 너무 어렵구만~", faceHero:"npcOperationOfficer"},
			  { type: "textMessage", text: "[$name] : 안녕하십니까! $name(이)라고 합니다", faceHero:"npcOperationOfficer"},
              { type: "textMessage", text: "[작전장교] : 죄송하지만 잠깐 비켜주시겠습니까?? ^제가 서랍에서 클린PC을 꺼내야 해서..", faceHero:"npcOperationOfficer"},
			  { type: "textMessage", text: "[$name] : 클린 PC 말입니까..?", faceHero:"npcOperationOfficer"},
              { type: "delStoryFlag", flag :"작전장교1"},
			  { type: "QuizMessage", text: "문제) 클린 PC란 무엇이고 왜 사용할까?(사이버보안 가이드 19페이지를 같이보면 좋을 것 같다!)", faceHero:"npcOperationOfficer",
			  option:["1. 완전 멸균된 PC이며 코로나 방역 간에 코로나 확산을 막기 위해 도입되었음",
			  "2. 네트워크와 연결되어있지 않고 자료 이동 간에 바이러스 검사를 실시하는 용도",
			  "3. 윈도우 운영체제 외에는 아무것도 깔려 있지 않은 PC",
			  "4. 윈도우가 아니라 리눅스가 설치되어있는 PC"]
			  ,ans:1,},
			  { type: "addStoryFlag", flag :"작전장교1"},
			  { who: "npcOperationOfficer", type: "stand",  direction: "right" },
            ]
          }
        ]
      }),
	  npcPlatoonCommander: new Person({	//통신소대장
        x: utils.withGrid(8),
        y: utils.withGrid(7),
		src: "./images/characters/people/지통실_통신소대장.png",
		behaviorLoop: [
          { type: "stand", direction: "up", time: 1000,},
        ],
		talking: [
		  {
            required:["작전담당부사관1","2중대장1","작전장교1","통신소대장1","교육화생방부사관1","작전과장1"],
            events:[
            {type : "textMessage", text:"(인사를 다 드렸으니 밖으로 가보자)"},
            ]
          },
          {
            required:["통신소대장1"],
            events:[
            {type : "textMessage", text:"도와줘서 고맙습니다. 다른 분들께 인사하러 가보세요.", faceHero:"npcPlatoonCommander"},
			{ who: "npcPlatoonCommander", type: "stand",  direction: "up" },
            ]
          },
          {
            events: [

              { type: "textMessage", text: "[통신소대장] : 흠.. 다행이다! 이 공기청정기에는 무선 LAN 카드가 없네 ", faceHero:"npcPlatoonCommander"},
			  { type: "textMessage", text: "[$name] : 통신소대장님! 저는 이번에 새로 전입 온 $name(이)라고 합니다.", faceHero:"npcPlatoonCommander"},
              { type: "textMessage", text: "[통신소대장] : 반갑습니다. 저는 대대 통신소대장입니다.", faceHero:"npcPlatoonCommander"},
			  { type: "textMessage", text: "[통신소대장] : 이번에 새로 구매한 공기청정기가 ^IoT 기능이 있다고 해서 확인하고 있었습니다. ", faceHero:"npcPlatoonCommander"},
			  { type: "textMessage", text: "[$name] : 아하! 안그래도 요즘 어플리케이션으로 제어하는 ^전자제품, 가구들이 많이 출시되고 있다고 들었습니다. ", faceHero:"npcPlatoonCommander"},
			  { type: "textMessage", text: "[통신소대장] : 잘알고 있으십니다. 안 그래도 요즘 KISA에서 ^IoT 관련 보안조치들이 많이 공지되고 있는데 우리도 주의해야 할 것 같습니다", faceHero:"npcPlatoonCommander",},
              { type: "delStoryFlag", flag :"통신소대장1"},
			  { type: "QuizMessage", text: "문제) 다음 전자기기 중 무선 LAN 카드를 확인하지 않아도 되는것은?^(사이버보안 가이드 20페이지를 같이보면 좋을 것 같다!)",faceHero:"npcPlatoonCommander",
			  option:["프린터","공기청정기","에어컨","VoIP(전화기)"],ans:3,},
			  { type: "addStoryFlag", flag :"통신소대장1"},
			  { who: "npcPlatoonCommander", type: "stand",  direction: "up" },
            ]
          }
        ]
      }),
	  npcEducationBusaguan: new Person({	//교육화생방부사관
        x: utils.withGrid(15),
        y: utils.withGrid(8),
		src: "./images/characters/people/지통실4.png",
		talking: [
		  {
            required:["작전담당부사관1","2중대장1","작전장교1","통신소대장1","교육화생방부사관1","작전과장1"],
            events:[
            {type : "textMessage", text:"(인사를 다 드렸으니 밖으로 가보자)"},
            ]
          },
          {
            required:["교육화생방부사관1"],
            events:[
            {type : "textMessage", text:"도와줘서 고맙습니다. 다른 분들께 인사하러 가보세요.", faceHero:"npcEducationBusaguan"},
			{ who: "npcEducationBusaguan", type: "stand",  direction: "down" },
            ]
          },
          {
            events: [
              { type: "addStoryFlag", flag :"교육화생방부사관1"},
              { type: "textMessage", text: "[$name] : 교육화생방부사관님! 좋은 일 있으십니까?", faceHero:"npcEducationBusaguan"},
			  { type: "textMessage", text: "[교육화생방부사관] : 충성! 앗.. 혹시 누구...", faceHero:"npcEducationBusaguan"},
              { type: "textMessage", text: "[$name] : 이번에 전입 온 $name(이)라고 합니다.", faceHero:"npcEducationBusaguan"},
			  { type: "textMessage", text: "[$name] : 근데.. 이거..곰플레이어에 있는 닷지 게임이네..?! ^곰플레이어를 군대에서 사용할 수 있습니까?", faceHero:"npcEducationBusaguan"},
			  { type: "textMessage", text: "사이버보안 가이드 21페이지를 확인해보자! ^(ENTER키를 입력하면 21페이지가 열린다.)", faceHero:"npcEducationBusaguan",book:21},
			  { type: "textMessage", text: "[교육화생방부사관] : 앗 들켜버렸다.. 바로 삭제하겠습니다 ", faceHero:"npcEducationBusaguan"},
			  
			  { who: "npcEducationBusaguan", type: "stand",  direction: "down" },
            ]
          }
        ]
      }),
	  npcChiefOfOperatons: new Person({	//작전과장
        x: utils.withGrid(15),
        y: utils.withGrid(12),
		src: "./images/characters/people/지통실5.png",
		behaviorLoop: [
          { type: "stand", direction: "up", time: 1000,},
        ],
		talking: [
		  {
            required:["작전담당부사관1","2중대장1","작전장교1","통신소대장1","교육화생방부사관1","작전과장1"],
            events:[
            {type : "textMessage", text:"(인사를 다 드렸으니 밖으로 가보자)"},
            ]
          },
          {
            required:["작전과장1"],
            events:[
            {type : "textMessage", text:"도와줘서 고맙습니다. 다른 분들께 인사하러 가보세요.", faceHero:"npcChiefOfOperatons"},
			{ who: "npcChiefOfOperatons", type: "stand",  direction: "up" },
            ]
          },
          {
            events: [
              { type: "addStoryFlag", flag :"작전과장1"},
              { type: "textMessage", text: "[$name] : 충성! 과장님 이번에 새로 전입온 $name입니다. ^앗.. 혹시 무슨 일 있으십니까?", faceHero:"npcChiefOfOperatons"},
			  { type: "textMessage", text: "[작전과장] : 지금 제가 바빠서.....  방금 군단 사이버방호실에서 전화가 왔는데,^제 컴퓨터에서 바이러스가 발견되었다고 합니다 ", faceHero:"npcChiefOfOperatons"},
              { type: "textMessage", text: "[$name] : 네?! 어떻게 그런 일이..??", faceHero:"npcChiefOfOperatons"},
			  { type: "textMessage", text: "[작전과장] : 일단 랜선을 분리했고 아무것도 만지지 말고 기다리라고 해서 ^사단 사이버방호실에서 올 때까지 기다리고 있습니다", faceHero:"npcChiefOfOperatons"},
			  { type: "textMessage", text: "[$name] : 아하.. PC에 무슨 일이 있었던 겁니까?", faceHero:"npcChiefOfOperatons"},
			  { type: "textMessage", text: "[작전과장] : 저번에 PC를 외주정비 맡기면서 하드디스크를 교체했다고 들었는데, ^교체된 하드디스크에 바이러스가 있었나봅니다 일단 그렇게 추정중입니다", faceHero:"npcChiefOfOperatons"},
			  { type: "textMessage", text: "[$name] : 아하.. 요즘에 외주업체나 내부자에 의한 침해행위가 증가했다고 합니다... ", faceHero:"npcChiefOfOperatons"},
			  { type: "textMessage", text: "사이버보안 가이드 22페이지를 같이보면 좋을 것 같다! ^(ENTER키를 입력하면 22페이지가 열린다.)", faceHero:"npcChiefOfOperatons",book:22},
			  { type: "textMessage", text: "[작전과장] : 다행히 중요한 파일은 없고, 혹시 몰라 바이러스 검사도 실시했으니 ^망정이지..  군생활 동안 이런 침해행위들 주의하시는게 좋을것 같습니다.", faceHero:"npcChiefOfOperatons"},
			  { type: "textMessage", text: "[작전과장] :  무슨 일이 발생하면 랜선 분리 후에 사이버방호실 0188로 신고해야합니다!!", faceHero:"npcChiefOfOperatons"},
			 
			  { who: "npcChiefOfOperatons", type: "stand",  direction: "up" },
            ]
          }
        ]
      }), 
      
	quest_npcChiefOfOperatons: new Quest({
       x: utils.withGrid(15)-1,
       y: utils.withGrid(11)-1,
        storyFlag: "작전과장1",
		who:"quest",
      }),
	quest_npcEducationBusaguan: new Quest({
       x: utils.withGrid(15)-1,
       y: utils.withGrid(7)-1,
        storyFlag: "교육화생방부사관1",
		who:"quest",
      }),
	quest_npcOperationOfficer: new Quest({
       x: utils.withGrid(9)-1,
       y: utils.withGrid(10)-1,
        storyFlag: "작전장교1",
		who:"quest",
      }),
	quest_npc2CompanyCommander: new Quest({
       x: utils.withGrid(9)-1,
       y: utils.withGrid(8)-1,
        storyFlag: "2중대장1",
		who:"quest",
      }),
	quest_npcOperationsBusaguan: new Quest({
       x: utils.withGrid(9)-1,
       y: utils.withGrid(6)-1,
        storyFlag: "작전담당부사관1",
		who:"quest",
      }),
	quest_npcPlatoonCommander: new Quest({
       x: utils.withGrid(8)-1,
       y: utils.withGrid(6)-1,
        storyFlag: "통신소대장1",
		who:"quest",
      }),
    },
    walls: {
      [utils.asGridCoord(14,6)] : true,
      [utils.asGridCoord(15,6)] : true,
      [utils.asGridCoord(16,6)] : true,
      [utils.asGridCoord(17,6)] : true,

      [utils.asGridCoord(17,9)] : true,
      [utils.asGridCoord(16,9)] : true,
      [utils.asGridCoord(15,9)] : true,
      [utils.asGridCoord(14,9)] : true,
      [utils.asGridCoord(17,8)] : true,
      [utils.asGridCoord(0,0)] : true,
      [utils.asGridCoord(0,0)] : true,
      [utils.asGridCoord(14,14)] : true,
      [utils.asGridCoord(15,14)] : true,
      [utils.asGridCoord(16,14)] : true,
      [utils.asGridCoord(17,14)] : true,
      [utils.asGridCoord(18,13)] : true,
      [utils.asGridCoord(18,12)] : true,
      [utils.asGridCoord(18,11)] : true,
      [utils.asGridCoord(18,10)] : true,
      [utils.asGridCoord(18,9)] : true,
      [utils.asGridCoord(18,8)] : true,
      [utils.asGridCoord(18,7)] : true,
      [utils.asGridCoord(18,6)] : true,
      [utils.asGridCoord(18,5)] : true,
      [utils.asGridCoord(17,5)] : true,
      [utils.asGridCoord(16,5)] : true,
      [utils.asGridCoord(15,5)] : true,
      [utils.asGridCoord(14,5)] : true,
      [utils.asGridCoord(13,5)] : true,
      [utils.asGridCoord(12,5)] : true,
      [utils.asGridCoord(11,5)] : true,
      [utils.asGridCoord(10,5)] : true,
      [utils.asGridCoord(9,5)] : true,
      [utils.asGridCoord(8,5)] : true,
      [utils.asGridCoord(7,5)] : true,
      [utils.asGridCoord(6,5)] : true,
      [utils.asGridCoord(6,6)] : true,
      [utils.asGridCoord(7,6)] : true,
      [utils.asGridCoord(5,5)] : true,
      [utils.asGridCoord(5,6)] : true,
      [utils.asGridCoord(5,7)] : true,
      [utils.asGridCoord(5,8)] : true,
      [utils.asGridCoord(5,9)] : true,
      [utils.asGridCoord(5,10)] : true,
      [utils.asGridCoord(5,11)] : true,
      [utils.asGridCoord(5,12)] : true,
      [utils.asGridCoord(5,13)] : true,
      [utils.asGridCoord(5,14)] : true,
      [utils.asGridCoord(6,14)] : true,
      [utils.asGridCoord(7,14)] : true,
      [utils.asGridCoord(8,14)] : true,
      [utils.asGridCoord(9,14)] : true,
      [utils.asGridCoord(10,14)] : true,
      [utils.asGridCoord(11,14)] : true,
      [utils.asGridCoord(12,14)] : true,
      [utils.asGridCoord(8,6)] : true,
      [utils.asGridCoord(9,6)] : true,
      [utils.asGridCoord(10,6)] : true,
      [utils.asGridCoord(10,7)] : true,
      [utils.asGridCoord(10,8)] : true,
      [utils.asGridCoord(10,9)] : true,
      [utils.asGridCoord(10,10)] : true,
      [utils.asGridCoord(10,11)] : true,
 
      [utils.asGridCoord(13,9)] : true,
      [utils.asGridCoord(13,10)] : true,
      [utils.asGridCoord(14,10)] : true,
      [utils.asGridCoord(15,10)] : true,
      [utils.asGridCoord(16,10)] : true,
      [utils.asGridCoord(17,10)] : true,
      [utils.asGridCoord(13,11)] : true,
      [utils.asGridCoord(14,11)] : true,
      [utils.asGridCoord(15,11)] : true,
      [utils.asGridCoord(16,11)] : true,
      [utils.asGridCoord(17,11)] : true,
    },
    cutsceneSpaces: {
		
      [utils.asGridCoord(13,14)]: [
		{
			required : ["작전담당부사관1","2중대장1","작전장교1","통신소대장1","교육화생방부사관1","작전과장1"],
			events: [
            {
              type: "changeMap", 
              map: "Hall2", 
              x: utils.withGrid(21),
              y: utils.withGrid(4), 
              direction: "down"	
			}
			]			
		},
		{
			events:[
				{type:"textMessage",text:"아직 모든 간부님들께 인사를 드리지 못했다. 마저 말을 걸어보자."},
				{ who: "hero", type: "walk",  direction: "up" },
			]
		}
	  ]
    }
  },  
  Office: {
    id: "Office",
    lowerSrc: "./images/map/office.png",
    upperSrc: "./images/map/empty.png",
    gameObjects: {
	quest_A: new Quest({
       x: utils.withGrid(3)-1,
       y: utils.withGrid(5)-1,
        storyFlag: "중대장1",
		who:"quest",
      }),
	quest_B: new Quest({
       x: utils.withGrid(8)-1,
       y: utils.withGrid(4)-1,
        storyFlag: "행정보급관1가기",
		who:"quest",
      }),
	quest_C: new Quest({
       x: utils.withGrid(8)-1,
       y: utils.withGrid(9)-1,
        storyFlag: "분대장1가기",
		who:"quest",
      }),
	quest_D: new Quest({
       x: utils.withGrid(8)-1,
       y: utils.withGrid(7)-1,
        storyFlag: "박격포반장1가기",
		who:"quest",
      }),
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(0),
        y: utils.withGrid(0),
      }),
	  sprite1: new Person({
        x: utils.withGrid(3)-2,
        y: utils.withGrid(6)+3,
        src: "./images/office/sprite1.png",	
		who: "object"
      }), 	
	  sprite2: new Person({
        x: utils.withGrid(8)+6,
        y: utils.withGrid(10)+6,
        src: "./images/office/sprite2.png",	
		who: "object"
      }), 
	중대장: new Person({
        x: utils.withGrid(3),
        y: utils.withGrid(6),
        src: "./images/characters/people/hang1.png",
        talking: [
          {
            required:["박격포반장1","중대장1","분대장1","행정보급관1"],
            events:[
            {type : "textMessage", text:"(인사를 다 드렸으니 지휘통제실로 가보자)"},
            ]
          },          
          {
            required:["중대장1"],
            events:[
            {type : "textMessage", text:"[중대장]: 앞으로 잘해봅시다.", faceHero:"중대장"},
			{type : "textMessage", text:"(다른 사람들에게 인사드리러 가자)"},
			{ who: "중대장", type: "stand",  direction: "down" },
            ]
          },
          {
            events: [
              
			  

			  { type: "textMessage", text: "[$name]: 중대장님 안녕하십니까, 이번에 새로 전입온 $name이라고 합니다."},
              { type: "textMessage", 
			  text: "[중대장] : (무언가 열심히 보고 있다가) 새로 전입오신 간부이십니까? 반갑습니다.",
			  faceHero:"중대장"},
              { type: "textMessage", 
			  text: "[중대장] : 오늘 사이버보안진단의 날이라서 정신이 없었습니다."},
              { type: "textMessage", 
			  text: "[$name] : 사이버보안진단의 날 말씀이십니까..?"},
              { type: "textMessage", 
			  text: "[중대장] : 한 번 같이 체크리스트를 확인해보시겠습니까?", book:2},
              { type: "textMessage", 
			  text: "(*체크리스트를 다 확인한 후*)"},
              { type: "textMessage", 
			  text: "[중대장] : 사이버보안진단의 날은 매월 세번째 금요일이고,^앞으로 군생활하면서 계속 하게 될겁니다! 오늘한 내용을 까먹지 말아 주십쇼"},
              { type: "textMessage", 
			  text: "[$name]: 네 알겠습니다! "},
			  { who: "중대장", type: "stand",  direction: "down" },
			  { type: "addStoryFlag", flag :"중대장1"},
              { type: "delStoryFlag", flag: "행정보급관1가기"},
			  
            ]
          }
        ]
      }),
	행정보급관: new Person({
        x: utils.withGrid(8),
        y: utils.withGrid(5),
        src: "./images/characters/people/hang2.png",
        talking: [
          {
            required:["박격포반장1","중대장1","분대장1","행정보급관1"],
            events:[
            {type : "textMessage", text:"(인사를 다 드렸으니 지휘통제실로 가보자)"},
            ]
          },          
          {
            required:["행정보급관1"],
            events:[
            {type : "textMessage", text:"(다른 사람들에게 인사드리러 가자)"},
            ]
          },
          {
			required:["중대장1"],
            events: [
              { type: "addStoryFlag", flag :"행정보급관1"},
			  { type: "addStoryFlag", flag: "행정보급관1가기"},
			  
			{ type: "textMessage", 
			  text: "[행정보급관] : 안녕하십니까?^사이버보안진단의 날에는 빼먹을 수 없는게 하나 더 있습니다! 저랑 같이해보시죠",
			  faceHero:"행정보급관"},
              { type: "textMessage", 
			  text: "[$name] : 네! 좋습니다. 혹시 어떤 것입니까?"},
              { type: "textMessage", 
			  text: "[행정보급관] : 보안규정평가라고 있는데 은근히 어렵습니다~^그래도 똑똑하시니까 통과할 수 있을 겁니다!",book:5},
              { type: "textMessage", 
			  text: "( 보안규정평가 다 끝나고)"},
              { type: "textMessage", 
			  text: "[행정보급관] : 오  보안규정평가를 한번에 통과하셨다니 대단하십니다"},
              { type: "textMessage", 
			  text: "[$name] : 하하 제가 보안교육을 열심히 들어서.. 감사합니다!"},
			  { who: "행정보급관", type: "stand",  direction: "down" },
			  { type: "addStoryFlag", flag :"행정보급관1"},
			  { type: "delStoryFlag", flag: "박격포반장1가기"},
            ]
          },
		  {
            events:[
				{type : "textMessage", text:"...왼쪽에 계신 중대장님께 먼저 인사를 드려야 할 것 같다."},
            ] 
		  }
        ]
      }),
	분대장: new Person({
		x: utils.withGrid(8),
        y: utils.withGrid(10),
        src: "./images/characters/people/hang3.png",
		behaviorLoop: [
          { type: "stand", direction: "right", time: 1000,},
        ],
        talking: [
          {
            required:["박격포반장1","중대장1","분대장1","행정보급관1"],
            events:[
            {type : "textMessage", text:"(인사를 다 드렸으니 지휘통제실로 가보자)"},
            ]
          },          
          {
            required:["분대장1"],
            events:[
            {type : "textMessage", text:"(열심히 업무를 보는것 같다. 다른 사람에게 가자)"},
            ]
          },

          {
			required:["중대장1","행정보급관1","박격포반장1"],
            events: [

				{ type: "addStoryFlag", flag: "분대장1가기"},  
			{ type: "textMessage", 
			  text: "[행정보급관] : 앗! 김하사 지금 뭐하는 거야?"},
              { type: "textMessage", 
			  text: "[분대장] : 예? 저 지금 부소대장님께서.. 당직 근무표를 찍어서 ^카톡으로 보내달라고 하셔서 휴대폰으로 촬영하려고 했습니다",
			  faceHero:"분대장"},
              { type: "textMessage", 
			  text: "[행정보급관] : 뭐라구? 모바일 보안 어플로 카메라가 잠길텐데.."},
              { type: "textMessage", 
			  text: "[분대장] : 안 그래도 그것 때문에 촬영을 못하고 있었습니다 ㅜㅜ"},
              { type: "textMessage", 
			  text: "[행정보급관] : 어이쿠! 이번에 새로운 간부님도 오셨는데 창피하지도 않니??"},
              { type: "textMessage", 
			  text: "[$name] : 하하 괜찮습니다!^김하사님 보안위규 사항은 군생활에 막대한 영향을 미치니 다음부터는 주의해주십쇼!"},
			  { who: "분대장", type: "stand",  direction: "right" },
			  { type: "addStoryFlag", flag :"분대장1"},	
            ]
          },
			{
			required:["중대장1","행정보급관1"],
            events:[
            {type : "textMessage", text:"(박격포반장님에게 인사드리러 가자)"},
            ]
				
			},
			{
			required:["중대장1"],
            events:[
            {type : "textMessage", text:"(행정보급관님에게 인사드리러 가자)"},
            ]
				
			},
		  {
            events:[
				{type : "textMessage", text:"(...왼쪽에 계신 중대장님께 먼저 인사를 드려야 할 것 같다.)"},
            ] 
		  }
        ]
      }),
	박격포반장: new Person({
		x: utils.withGrid(8),
        y: utils.withGrid(8),
        src: "./images/characters/people/hang4.png",
		behaviorLoop: [
          { type: "stand", direction: "right", time: 1000,},
        ],
        talking: [
          {
            required:["박격포반장1","중대장1","분대장1","행정보급관1"],
            events:[
            {type : "textMessage", text:"(인사를 다 드렸으니 지휘통제실로 가보자)"},
            ]
          },
          {
            required:["박격포반장1"],
            events:[
            {type : "textMessage", text:"(다른 사람에게 인사드리러 가자)"},
            ]
          },
			
          {
			required:["중대장1","행정보급관1"],
            events: [
			  	    
			  { type: "addStoryFlag", flag: "박격포반장1가기"},
			  
              { type: "textMessage", 
			  text: "[박격포반장] : 충성! 오시느라 고생 많으셨습니다! 저는 박격포반장입니다.",
			  faceHero:"박격포반장"},
              { type: "textMessage", 
			  text: "[$name] : 잘 부탁드립니다!^이번에 전입온 $name(이)라고 합니다. 지금 어떤거 하고 계셨습니까?"},
              { type: "textMessage", 
			  text: "[박격포반장] : 아 네 ^오늘 사이버보안진단의 날 이어서 중대에 있는 신인성검사 PC를 확인하고 있었습니다."},
              { type: "textMessage", 
			  text: "[박격포반장] : 안 켠지 오래되서 그런지 필수설치 SW 버전도 안 맞습니다.."},
              { type: "textMessage", 
			  text: "[박격포반장] : 아 개인 PC를 받으실텐데,^이 참에 필수 설치 프로그램에 대해 알아보시는게 어떻습니까?"},
              { type: "textMessage", 
			  text: "[$name] :아 좋습니다! "},
			  { type: "delStoryFlag", flag: "박격포반장1가기"},
              { type: "QuizMessage", text: "문제) 다음 중 필수 설치 보안 SW가 아닌 것은?!^(사이버보안 가이드 7~14페이지를 참고하면 좋을 것 같다!)"
			  , option:["문서암호화", "백신", "곰플레이어", "저장매체통제체계"],ans: 2},
			  { who: "박격포반장", type: "stand",  direction: "right" },
			  { type: "addStoryFlag", flag: "박격포반장1가기"},
			  { type: "delStoryFlag", flag: "분대장1가기"},
			  { type: "addStoryFlag", flag :"박격포반장1"},
            ]
          },
			{
			required:["중대장1"],
            events:[
            {type : "textMessage", text:"(행정보급관님에게 인사드리러 가자)"},
            ]
				
			},
		  {
            events:[
				{type : "textMessage", text:"...왼쪽에 계신 중대장님께 먼저 인사를 드려야 할 것 같다."},
            ] 
		  }
        ]
      }),
    },
	walls: {
      [utils.asGridCoord(7,6)] : true,             
      [utils.asGridCoord(8,6)] : true,         
      [utils.asGridCoord(9,6)] : true, 
      [utils.asGridCoord(9,7)] : true, 
      [utils.asGridCoord(9,8)] : true,                 
      [utils.asGridCoord(9,9)] : true, 
      [utils.asGridCoord(9,10)] : true, 
      [utils.asGridCoord(9,11)] : true,         
        
        
      [utils.asGridCoord(2,7)] : true, 
      [utils.asGridCoord(3,7)] : true, 
      [utils.asGridCoord(4,7)] : true, 
        
      [utils.asGridCoord(0,0)] : true,
      [utils.asGridCoord(0,0)] : true,
      [utils.asGridCoord(9,12)] : true,
      [utils.asGridCoord(10,12)] : true,
      [utils.asGridCoord(11,12)] : true,
      [utils.asGridCoord(10,11)] : true,
      [utils.asGridCoord(10,10)] : true,
      [utils.asGridCoord(10,9)] : true,
      [utils.asGridCoord(10,8)] : true,
      [utils.asGridCoord(10,7)] : true,
      [utils.asGridCoord(10,6)] : true,
      [utils.asGridCoord(10,5)] : true,
      [utils.asGridCoord(10,4)] : true,
      [utils.asGridCoord(10,3)] : true,
      
      [utils.asGridCoord(9,3)] : true,
      [utils.asGridCoord(8,3)] : true,
      [utils.asGridCoord(7,3)] : true,
      [utils.asGridCoord(6,3)] : true,
      [utils.asGridCoord(5,3)] : true,
      [utils.asGridCoord(4,3)] : true,
      [utils.asGridCoord(3,3)] : true,
      [utils.asGridCoord(2,3)] : true,
      [utils.asGridCoord(1,3)] : true,
      [utils.asGridCoord(1,4)] : true,
      [utils.asGridCoord(1,5)] : true,
      [utils.asGridCoord(1,6)] : true,
      [utils.asGridCoord(1,7)] : true,
      [utils.asGridCoord(1,8)] : true,
      [utils.asGridCoord(1,9)] : true,
      [utils.asGridCoord(1,10)] : true,
      [utils.asGridCoord(1,11)] : true,
      [utils.asGridCoord(1,12)] : true,
      [utils.asGridCoord(2,12)] : true,
      [utils.asGridCoord(3,12)] : true,
      [utils.asGridCoord(4,12)] : true,
      [utils.asGridCoord(5,12)] : true,
      [utils.asGridCoord(6,12)] : true,
      [utils.asGridCoord(7,12)] : true,
	  [utils.asGridCoord(8,13)] : true,
    },

            
	cutsceneSpaces: {
		
      [utils.asGridCoord(8,11)]: [
        {
		  required:["행정반입장"],
          events: []
        },
        {
          events: [

			{ type: "textMessage", text:"중대 간부들 앞에 가서 ENTER 키를 누르면 말을 걸 수 있습니다!"},
			{ type: "textMessage", text:"가까이 가서 ENTER키를 눌러 인사를 드려보세요!"},
			{ type: "addStoryFlag", flag :"행정반입장"},
                                    
          ]
        }
      ],
      [utils.asGridCoord(8,12)]: [
	    {
			required:["작전담당부사관1","2중대장1","작전장교1","통신소대장1","교육화생방부사관1","작전과장1"],
			events: [
              { 
              type: "changeMap", 
              map: "Hall2",
              x: utils.withGrid(6),
              y: utils.withGrid(4), 
              direction: "down"
              }
			]
		},
        {
		  required:["중대장1","행정보급관1","분대장1","박격포반장1",],
          events: [
	{ type: "delStoryFlag", flag :"지휘통제실로"},
	
            { 
            
              type: "changeMap", 
              map: "Hall",
              x: utils.withGrid(6),
              y: utils.withGrid(4), 
              direction: "down"
            }
          ]
        },
		{
		  events: [
            { type: "textMessage", text:"아직 모든 간부님들께 인사를 드리지 못했다. 마저 말을 걸어보자."},
			{ who: "hero", type: "walk",  direction: "up" },
          ]
		}
      ]
    }
  },
  Hall: {
    id: "Hall",
    lowerSrc: "./images/handmade/hallway.png",
    upperSrc: "./images/handmade/empty.png",
	
	
    gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(14),
        y: utils.withGrid(8),
		direction:"up"
      }),
      sprite1: new Quest({
       x: utils.withGrid(6),
       y: utils.withGrid(2)-1,
        storyFlag: "분대장1",
		who:"quest",
      }),   	   
      sprite2: new Quest({
       x: utils.withGrid(21)+5,
       y: utils.withGrid(2)-1,
        storyFlag: "지휘통제실로",
		who:"quest",
      }),   	     
    },
    walls: {
      [utils.asGridCoord(0,0)] : true,
	  [utils.asGridCoord(1,6)] : true,
	  [utils.asGridCoord(1,5)] : true,
	  [utils.asGridCoord(1,4)] : true,
	  [utils.asGridCoord(2,3)] : true,
	  [utils.asGridCoord(3,3)] : true,
	  [utils.asGridCoord(4,4)] : true,			
	  [utils.asGridCoord(5,3)] : true,
	  [utils.asGridCoord(7,3)] : true,
	  [utils.asGridCoord(8,3)] : true,
	  [utils.asGridCoord(9,3)] : true,
	  [utils.asGridCoord(10,3)] : true,
	  [utils.asGridCoord(11,3)] : true,
	  [utils.asGridCoord(12,3)] : true,
	  [utils.asGridCoord(12,1)] : true,
	  [utils.asGridCoord(12,2)] : true,
	  [utils.asGridCoord(12,0)] : true,
	  [utils.asGridCoord(0,7)] : true,
	  [utils.asGridCoord(1,7)] : true,
	  [utils.asGridCoord(2,7)] : true,
	  [utils.asGridCoord(3,7)] : true,
	  [utils.asGridCoord(4,7)] : true,
	  [utils.asGridCoord(5,7)] : true,
	  [utils.asGridCoord(6,7)] : true,
	  [utils.asGridCoord(7,7)] : true,
	  [utils.asGridCoord(8,7)] : true,
	  [utils.asGridCoord(9,7)] : true,
	  [utils.asGridCoord(10,7)] : true,
	  [utils.asGridCoord(11,7)] : true,
	  [utils.asGridCoord(12,7)] : true,
	  [utils.asGridCoord(12,8)] : true,
	  [utils.asGridCoord(13,9)] : true,
	  [utils.asGridCoord(14,10)] : true,
	  [utils.asGridCoord(15,9)] : true,
	  [utils.asGridCoord(16,8)] : true,
	  [utils.asGridCoord(16,7)] : true,
	  [utils.asGridCoord(17,7)] : true,
	  [utils.asGridCoord(18,7)] : true,
	  [utils.asGridCoord(19,7)] : true,
	  [utils.asGridCoord(20,7)] : true,
	  [utils.asGridCoord(21,7)] : true,
	  [utils.asGridCoord(22,7)] : true,
	  [utils.asGridCoord(23,7)] : true,
	  [utils.asGridCoord(24,7)] : true,
	  [utils.asGridCoord(25,7)] : true,
	  [utils.asGridCoord(26,7)] : true,
	  [utils.asGridCoord(27,7)] : true,
	  [utils.asGridCoord(27,6)] : true,
	  [utils.asGridCoord(27,5)] : true,
	  [utils.asGridCoord(27,4)] : true,
	  [utils.asGridCoord(27,3)] : true,
	  [utils.asGridCoord(26,3)] : true,
	  [utils.asGridCoord(25,3)] : true,
	  [utils.asGridCoord(24,3)] : true,
	  [utils.asGridCoord(23,3)] : true,
	  [utils.asGridCoord(21,2)] : true,
	  [utils.asGridCoord(20,3)] : true,
	  [utils.asGridCoord(19,3)] : true,
	  [utils.asGridCoord(18,3)] : true,
	  [utils.asGridCoord(17,3)] : true,
	  [utils.asGridCoord(16,3)] : true,
	  [utils.asGridCoord(16,2)] : true,
	  [utils.asGridCoord(16,2)] : true,
	  [utils.asGridCoord(16,1)] : true,
	  [utils.asGridCoord(16,0)] : true,
	  [utils.asGridCoord(16,-1)] : true,
	  [utils.asGridCoord(15,-1)] : true,
	  [utils.asGridCoord(14,-1)] : true,
	  [utils.asGridCoord(13,-1)] : true,
	  [utils.asGridCoord(12,-1)] : true,
	  
    },
    cutsceneSpaces: {
      [utils.asGridCoord(14,8)]: [
        {
		  required:["복도입장",],
          events: []
        },
		{
			events:[
                {type: "addStoryFlag", flag: "대대장의문제1"},
				{ type: "addStoryFlag", flag: "행정보급관1가기"},
				{ type: "addStoryFlag", flag: "분대장1가기"},
				{ type: "addStoryFlag", flag: "박격포반장1가기"},
				{type:"textMessage", text:"행정반과 지통실에 들려 간부들에게 인사를 드리자"},
				{type:"textMessage", text:"행정반은 좌측, 지통실은 우측에 있다."},
				{type:"textMessage", text:"행정반에 먼저 가보도록 하자."},
				{type:"addStoryFlag",flag:"복도입장"},
				{ who: "hero", type: "walk",  direction: "up" },
			]
		}
		
      ],        
      [utils.asGridCoord(14,9)]: [
        {
		  required:["퇴근"],
          events: [
            { 
              type: "changeMap", 
              map: "OutSide",
              x: utils.withGrid(41),
              y: utils.withGrid(9), 
              direction: "down"
            }
          ]
        },
        {
          events: [
              {type:"textMessage", text:"(아직 할일이 남아있다.. 행정반 혹은 지휘통제실을 가보자)"},
			  { who: "hero", type: "walk",  direction: "up" },
			  
          ]
        }

      ],
      [utils.asGridCoord(21,3)]: [
        {
		  required:["중대장1","행정보급관1","분대장1","박격포반장1",],
          events: [
			{ type: "addStoryFlag", flag: "행정보급관1가기"},
			{ type: "addStoryFlag", flag: "분대장1가기"},
			{ type: "addStoryFlag", flag: "박격포반장1가기"},
		  
		  
            { 
              type: "changeMap", 
              map: "CommandCenter",
              x: utils.withGrid(13),
              y: utils.withGrid(13), 
              direction: "up"
            }
          ]
        },
		{
			events:[
				{type:"textMessage", text:"아직 행정반에 들리지 않았다.(행정반은 좌측에 있을거 같다)"},
				{ who: "hero", type: "walk",  direction: "down" },
			]
		}
		
      ],
	  
      [utils.asGridCoord(22,3)]: [
        {
		  required : ["중대장1","행정보급관1","분대장1","박격포반장1",],
          events: [

            { 
            
              type: "changeMap", 
              map: "CommandCenter",
              x: utils.withGrid(13),
              y: utils.withGrid(13), 
              direction: "up"
            }
          ]
        },
		{
			events:[
				{type:"textMessage", text:"아직 행정반에 들리지 않았다.(행정반은 좌측에 있을거 같다)"},
				{ who: "hero", type: "walk",  direction: "down" },
			]
		}
      ],
      [utils.asGridCoord(6,3)]: [
        {
          events: [
            { 
              type: "changeMap", 
              map: "Office",
              x: utils.withGrid(8),
              y: utils.withGrid(12), 
              direction: "up"
            }
          ]
        }
      ],	  
	  
    }
  }, 
  Hall2: {
    id: "Hall2",
    lowerSrc: "./images/handmade/hallway.png",
    upperSrc: "./images/handmade/empty.png",
	gameObjects: {
      hero: new Person({
        isPlayerControlled: true,
        x: utils.withGrid(14),
        y: utils.withGrid(8),
		direction:"up"
      }),
      npcA: new Person({
        x: utils.withGrid(14),
        y: utils.withGrid(0),
		direction:"down",
		src: "./images/characters/people/대대장.png",
        talking: [
          {
            required:["퇴근"],
            events:[
            {type : "textMessage", text:"앞으로도 사이버보안을 준수하면서 잘 지내봅시다.",faceHero:"npcA"},
			{ who: "npcA", type:"stand", direction:"up"},
            ]
          },
		{	
			required:["대대장의문제"], 
			events:[
                {type: "delStoryFlag", flag: "대대장의문제1"},
				{type:"textMessage", text:"[대대장] : 문제를 다시 내보도록 하지! 이번에는 맞추도록!"},
				{type:"textMessage", text:"[대대장] : 이번에도 사이버보안 가이드를 참고 해도 좋다!"},
				{type: "QuizMessage", text: "문제1) 국방망의 LAN선 색깔은?", option:["회색", "파란색", "노란색", "빨간색"],ans: 0,},
				{type: "QuizMessage", text: "문제2) 국방망에서 사용하는 백신 프로그램 이름은?", option:["V3", "바이로봇", "알약", "다잡아"],ans: 0,},
				{type: "QuizMessage", text: "문제3) 사이버방호실 전화번호는?", option:["0188", "0288", "0388", "0488"],ans: 0,},
				{type: "QuizMessage", text: "문제4) 다음 중 반입하면 안되는 것은?", option:["일체형 충전기", "분리형 충전기", "HDMI케이블", "RGB케이블"],ans: 1,},
                {type: "addStoryFlag", flag: "대대장의문제1"},
				{type:"textMessage", text:"[대대장] : 이정도면 훌륭하구만!"},
				{type:"textMessage", text:"[$name] : 감사합니다! 충성!"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"up"},				
				{type:"textMessage", text:"(오늘 하루 일과가 끝났다. 위병소로가자!)"},
				{type: "addStoryFlag", flag: "퇴근"},
                {type: "delStoryFlag", flag: "찐찐퇴근"},
			]
		},
		{
			events:[]
		}
		  
		  ],
      }),

	quest_np: new Quest({
       x: utils.withGrid(14)-1,
       y: utils.withGrid(4)-1,
        storyFlag: "대대장의문제1",
		who:"quest",
      }),     
    },
    
    walls: {
      [utils.asGridCoord(0,0)] : true,
	  [utils.asGridCoord(1,6)] : true,
	  [utils.asGridCoord(1,5)] : true,
	  [utils.asGridCoord(1,4)] : true,
	  [utils.asGridCoord(2,3)] : true,
	  [utils.asGridCoord(3,3)] : true,
	  [utils.asGridCoord(4,4)] : true,			
	  [utils.asGridCoord(5,3)] : true,
	  [utils.asGridCoord(7,3)] : true,
	  [utils.asGridCoord(8,3)] : true,
	  [utils.asGridCoord(9,3)] : true,
	  [utils.asGridCoord(10,3)] : true,
	  [utils.asGridCoord(11,3)] : true,
	  [utils.asGridCoord(12,3)] : true,
	  [utils.asGridCoord(12,1)] : true,
	  [utils.asGridCoord(12,2)] : true,
	  [utils.asGridCoord(12,0)] : true,
	  [utils.asGridCoord(0,7)] : true,
	  [utils.asGridCoord(1,7)] : true,
	  [utils.asGridCoord(2,7)] : true,
	  [utils.asGridCoord(3,7)] : true,
	  [utils.asGridCoord(4,7)] : true,
	  [utils.asGridCoord(5,7)] : true,
	  [utils.asGridCoord(6,7)] : true,
	  [utils.asGridCoord(7,7)] : true,
	  [utils.asGridCoord(8,7)] : true,
	  [utils.asGridCoord(9,7)] : true,
	  [utils.asGridCoord(10,7)] : true,
	  [utils.asGridCoord(11,7)] : true,
	  [utils.asGridCoord(12,7)] : true,
	  [utils.asGridCoord(12,8)] : true,
	  [utils.asGridCoord(13,9)] : true,
	  [utils.asGridCoord(14,10)] : true,
	  [utils.asGridCoord(15,9)] : true,
	  [utils.asGridCoord(16,8)] : true,
	  [utils.asGridCoord(16,7)] : true,
	  [utils.asGridCoord(17,7)] : true,
	  [utils.asGridCoord(18,7)] : true,
	  [utils.asGridCoord(19,7)] : true,
	  [utils.asGridCoord(20,7)] : true,
	  [utils.asGridCoord(21,7)] : true,
	  [utils.asGridCoord(22,7)] : true,
	  [utils.asGridCoord(23,7)] : true,
	  [utils.asGridCoord(24,7)] : true,
	  [utils.asGridCoord(25,7)] : true,
	  [utils.asGridCoord(26,7)] : true,
	  [utils.asGridCoord(27,7)] : true,
	  [utils.asGridCoord(27,6)] : true,
	  [utils.asGridCoord(27,5)] : true,
	  [utils.asGridCoord(27,4)] : true,
	  [utils.asGridCoord(27,3)] : true,
	  [utils.asGridCoord(26,3)] : true,
	  [utils.asGridCoord(25,3)] : true,
	  [utils.asGridCoord(24,3)] : true,
	  [utils.asGridCoord(23,3)] : true,
	  [utils.asGridCoord(21,2)] : true,
	  [utils.asGridCoord(20,3)] : true,
	  [utils.asGridCoord(19,3)] : true,
	  [utils.asGridCoord(18,3)] : true,
	  [utils.asGridCoord(17,3)] : true,
	  [utils.asGridCoord(16,3)] : true,
	  [utils.asGridCoord(16,2)] : true,
	  [utils.asGridCoord(16,2)] : true,
	  [utils.asGridCoord(16,1)] : true,
	  [utils.asGridCoord(16,0)] : true,
	  [utils.asGridCoord(16,-1)] : true,
	  [utils.asGridCoord(15,-1)] : true,
	  [utils.asGridCoord(14,-1)] : true,
	  [utils.asGridCoord(13,-1)] : true,
	  [utils.asGridCoord(12,-1)] : true,
	  
    },
    cutsceneSpaces: {
		[utils.asGridCoord(19,4)]: [
		{
			required:["대대장의문제"],
			events:[
			]
			
		},
		
		
		{	
			required:["시작"], 
			events:[

				{type:"textMessage", text:"!"},
                
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "hero", type:"walk", direction:"left"},
				{ who: "hero", type:"walk", direction:"down"},
				{ who: "hero", type:"walk", direction:"left"},
				{ who: "hero", type:"walk", direction:"left"},
				{ who: "hero", type:"walk", direction:"left"},

				
				{ who: "npcA", type:"stand", direction:"right"},
                {type: "addStoryFlag", flag: "대대장의문제"},
                {type: "delStoryFlag", flag: "대대장의문제1"},				
				{type:"textMessage", text:"[대대장] : 자네는 누구인가?"},
				
				{type:"textMessage", text:"[$name] : 충성! 이번에 전입 온 $name (이)라고 합니다."},
				{type:"textMessage", text:"[대대장] : 그래? 너 최근 여단장님 강조사항이 뭔지알고 있나?"},
				{type:"textMessage", text:"[$name] : 네! 인수인계서에서 확인했습니다! 사이버보안입니다."},
				{type:"textMessage", text:"[대대장] : 그럼 내가 얼마나 잘알고 있는지 문제를 내보도록하지!"},

				{type:"textMessage", text:"[대대장] : 사이버보안 가이드를 참고 해도 좋다!"},
                
				{type: "QuizMessage", text: "문제1) 국방망의 LAN선 색깔은?", option:["회색", "파란색", "노란색", "빨간색"],ans: 0,},
				{type: "QuizMessage", text: "문제2) 국방망에서 사용하는 백신 프로그램 이름은?", option:["V3", "바이로봇", "알약", "다잡아"],ans: 0,},
				{type: "QuizMessage", text: "문제3) 사이버방호실 전화번호는?", option:["0188", "0288", "0388", "0488"],ans: 0,},
				{type: "QuizMessage", text: "문제4) 다음 중 반입하면 안되는 것은?", option:["일체형 충전기", "분리형 충전기", "HDMI케이블", "RGB케이블"],ans: 1,},
                {type: "addStoryFlag", flag: "대대장의문제1"},
				{type:"textMessage", text:"[대대장] : 이정도면 훌륭하구만!"},
				{type:"textMessage", text:"[$name] : 감사합니다! 충성!"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"up"},				
				{type:"textMessage", text:"(오늘 하루 일과가 끝났다. 위병소로가자!)"},
				{type: "addStoryFlag", flag: "퇴근"},
                {type: "delStoryFlag", flag: "찐찐퇴근"},
			
			]
		},

		],

		[utils.asGridCoord(19,5)]: [
		{
			required:["대대장의문제"],
			events:[
			]
			
		},
		
		{	
			required:["시작"], 
			events:[
				{type:"textMessage", text:"!"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "hero", type:"walk", direction:"left"},
				{ who: "hero", type:"walk", direction:"left"},
				{ who: "hero", type:"walk", direction:"left"},
				{ who: "hero", type:"walk", direction:"left"},

				
				{ who: "npcA", type:"stand", direction:"right"},
				
				{type:"textMessage", text:"[대대장] : 자네는 누구인가?"},
				{type: "addStoryFlag", flag: "대대장의문제"},
				{type:"textMessage", text:"[$name] : 충성! 이번에 전입 온 $name 소위라고 합니다."},
				{type:"textMessage", text:"[대대장] : 그래? 너 최근 여단장님 강조사항이 뭔지알고 있나?"},
				{type:"textMessage", text:"[$name] : 네! 인수인계서에서 확인했습니다! 사이버보안입니다."},
				{type:"textMessage", text:"[대대장] : 그럼 내가 얼마나 잘알고 있는지 문제를 내보도록하지!"},
				{type:"textMessage", text:"[대대장] : 사이버보안 가이드를 참고 해도 좋다!"},
				{type: "QuizMessage", text: "문제1) 국방망의 LAN선 색깔은?", option:["회색", "파란색", "노란색", "빨간색"],ans: 0,},
				{type: "QuizMessage", text: "문제2) 국방망에서 사용하는 백신 프로그램 이름은?", option:["V3", "바이로봇", "알약", "다잡아"],ans: 0,},
				{type: "QuizMessage", text: "문제3) 사이버방호실 전화번호는?", option:["0188", "0288", "0388", "0488"],ans: 0,},
				{type: "QuizMessage", text: "문제4) 다음 중 반입하면 안되는 것은?", option:["일체형 충전기", "분리형 충전기", "HDMI케이블", "RGB케이블"],ans: 1,},
				{type:"textMessage", text:"[대대장] : 이정도면 훌륭하구만!"},
				{type:"textMessage", text:"[$name] : 감사합니다! 충성!"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"up"},				
				{type:"textMessage", text:"(오늘 하루 일과가 끝났다. 위병소로가자!)"},
				{type: "addStoryFlag", flag: "퇴근"},
			
			]
		},


		],
	
		[utils.asGridCoord(19,6)]: [
		{
			required:["대대장의문제"],
			events:[
			]
			
		},	
	
		{	
			required:["시작"], 
			events:[
				{type:"textMessage", text:"!"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "npcA", type:"walk", direction:"down"},
				{ who: "hero", type:"walk", direction:"left"},
				{ who: "hero", type:"walk", direction:"up"},
				{ who: "hero", type:"walk", direction:"left"},
				{ who: "hero", type:"walk", direction:"left"},
				{ who: "hero", type:"walk", direction:"left"},

				
				{ who: "npcA", type:"stand", direction:"right"},
				
				{type:"textMessage", text:"[대대장] : 자네는 누구인가?"},
				{type: "addStoryFlag", flag: "대대장의문제"},
				{type:"textMessage", text:"[$name] : 충성! 이번에 전입 온 $name 소위라고 합니다."},
				{type:"textMessage", text:"[대대장] : 그래? 너 최근 여단장님 강조사항이 뭔지알고 있나?"},
				{type:"textMessage", text:"[$name] : 네! 인수인계서에서 확인했습니다! 사이버보안입니다."},
				{type:"textMessage", text:"[대대장] : 그럼 내가 얼마나 잘알고 있는지 문제를 내보도록하지!"},
				{type:"textMessage", text:"[대대장] : 사이버보안 가이드를 참고 해도 좋다!"},
				{type: "QuizMessage", text: "문제1) 국방망의 LAN선 색깔은?", option:["회색", "파란색", "노란색", "빨간색"],ans: 0,},
				{type: "QuizMessage", text: "문제2) 국방망에서 사용하는 백신 프로그램 이름은?", option:["V3", "바이로봇", "알약", "다잡아"],ans: 0,},
				{type: "QuizMessage", text: "문제3) 사이버방호실 전화번호는?", option:["0188", "0288", "0388", "0488"],ans: 0,},
				{type: "QuizMessage", text: "문제4) 다음 중 반입하면 안되는 것은?", option:["일체형 충전기", "분리형 충전기", "HDMI케이블", "RGB케이블"],ans: 1,},
				{type:"textMessage", text:"[대대장] : 이정도면 훌륭하구만!"},
				{type:"textMessage", text:"[$name] : 감사합니다! 충성!"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"left"},
				{who: "npcA", type:"walk", direction:"up"},				
				{type:"textMessage", text:"(오늘 하루 일과가 끝났다. 위병소로가자!)"},
				{type: "addStoryFlag", flag: "퇴근"},
			
			]
		},


		],
      [utils.asGridCoord(14,9)]: [
        {
		  required:["퇴근"],
          events: [
            { 
              type: "changeMap", 
              map: "OutSide",
              x: utils.withGrid(41),
              y: utils.withGrid(9), 
              direction: "down"
            }
          ]
        },
		{
		  events:[
			{type:"textMessage", text: "아직 문제를 다 풀지 못했다. 대대장님께 말을 걸어보자."},
			{ who: "hero", type: "walk",  direction: "up" },
		  ]
		}
      ],
      [utils.asGridCoord(21,3)]: [
        {
		  required:["중대장1","행정보급관1","분대장1","박격포반장1",],
          events: [
            { 
              type: "changeMap", 
              map: "CommandCenter",
              x: utils.withGrid(13),
              y: utils.withGrid(13), 
              direction: "up"
            }
          ]
        },
		{
			events:[
				{type:"textMessage", text:"아직 행정반에 들리지 않았다.(행정반은 좌측에 있을거 같다)"},
				{ who: "hero", type: "walk",  direction: "down" },
			]
		}
      ],
	  

      [utils.asGridCoord(22,3)]: [
        {
		  required : ["중대장1","행정보급관1","분대장1","박격포반장1",],
          events: [
            { 
              type: "changeMap", 
              map: "CommandCenter",
              x: utils.withGrid(13),
              y: utils.withGrid(13), 
              direction: "up"
            }
          ]
        },
		{
			events:[
				{type:"textMessage", text:"아직 행정반에 들리지 않았다.(행정반은 좌측에 있을거 같다)"},
				{ who: "hero", type: "walk",  direction: "down" },
			]
		}
      ],
      [utils.asGridCoord(6,3)]: [
        {
          events: [
            { 
              type: "changeMap", 
              map: "Office",
              x: utils.withGrid(8),
              y: utils.withGrid(11), 
              direction: "up"
            }
          ]
        }
      ],	  
    }
  },    
}
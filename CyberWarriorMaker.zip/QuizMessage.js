class QuizMessage extends TextMessage{
	
  constructor({ text, onComplete }) {
    super({text,onComplete});
  }
  
  createElement() {
    this.element = document.createElement("div");
    this.element.classList.add("QuizMessage");

    this.element.innerHTML = (`
      <p class="TextMessage_p"></p>
      <button class = "QuizMessage_button">${this.option[0]}</button><br>
      <button class = "QuizMessage_button">${this.option[1]}</button><br>
      <button class = "QuizMessage_button">${this.option[2]}</button><br>
      <button class = "QuizMessage_button">${this.option[3]}</button>
    `)
	
    this.revealingText = new RevealingText({
      element: this.element.querySelector(".TextMessage_p"),
      text: this.text
    });
	
    const optionButtons=this.element.querySelectorAll("button");
    
    for(let i=0;i<4;i++){
      optionButtons[i].addEventListener("click", () => {
        this.element.classList.remove("QuizMessage");
        this.element.classList.add("TextMessage");
        const quizResult= (i==this.ans);
		let resultMessage;
		
        if(i==this.ans){
			resultMessage = "정답!!";
        }
        else{
			resultMessage = "사이버보안가이드를 다시 한 번 확인해보자... ( 확인한 후 대화를 걸어 다시 진행하자 )";
            decreaseLife();
        }
        
        this.element.innerHTML=(`<p class="TextMessage_p"></p>`);
        
        this.revealingText = new RevealingText({
            element: this.element.querySelector(".TextMessage_p"),
            text: resultMessage,
        });
        this.revealingText.init();
        
        this.actionListener = new KeyPressListener("Enter", () => {
            this.done(quizResult);
        });
      });
    }
  }

  done(quizResult) {
    if (this.revealingText.isDone) {
	  if(book_force!==0){
		if(move==1) return;
		book_move();
		if(book_force !== -1){
			book_open();
			page_swap(book_force);
		}
		return;
	  }
      this.element.remove();
      this.actionListener.unbind();
      this.onComplete(quizResult);
    } else {
      this.revealingText.warpToDone();
    }
  }  
}




/*
Person.js의 config에서 Quest라는 속성 추가해야함. this.Quiz ???내가 왜쓴거지
*/

//OverWorldEvent부분 수정해야함.
//OverworldEvent.js파일에서 EventFlag값이 어떻게 이용되는지 알아야함.
//
	/*
	done() {
	//입력이 들어오는 부분인데, 
	//올바른 답 인 경우 flag를 true로해주고, addFlag
	//올바르지 않은 답일 경우 life를 감소하는 메소드를 호출한다.
	
	
    if (this.revealingText.isDone) {
      this.element.remove();
      this.actionListener.unbind();
      this.onComplete();
    } else {
      this.revealingText.warpToDone();
    }
    */
    
    
    

/*
근본적인 기능을 수정한 부분
OverWorldEvent.js
OverWorl
*/
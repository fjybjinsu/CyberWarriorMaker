class PlayerState {
  constructor() {
    this.storyFlags = {
    };
  }
}
window.playerState = new PlayerState();